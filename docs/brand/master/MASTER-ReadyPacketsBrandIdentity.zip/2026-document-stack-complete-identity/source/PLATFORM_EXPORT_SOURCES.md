# Platform and Print Export Source Notes

`build_platform_and_print_exports.py` creates the upload-ready full-logo sizes under `platform-and-print-exports/`. It is a deterministic rendering layer over the approved local Document-Stack horizontal and square full-lockup masters.

## Inputs

- `logo-assets/readypackets-document-stack-light.svg`
- `logo-assets/readypackets-document-stack-dark.svg`
- `logo-assets/readypackets-document-stack-square-light.svg`
- `logo-assets/readypackets-document-stack-square-dark.svg`
- `icons/readypackets-document-stack-mark-light-*` and `...-dark-*` for explicitly separated browser/OS technical utility slots only
- `icons/readypackets-app-icon-*` for explicitly separated native/browser technical utility slots only
- `client/public/fonts/inter-400.woff2`, `inter-500.woff2`, `inter-600.woff2`, `inter-700.woff2`

## Outputs

Every customer-facing platform, social, print, email, LinkedIn, thumbnail, website, and app-launch export is built from a full lockup containing the Document-Stack, company name, Gold divider, and official slogan. Horizontal and square files differ only in composition to fit their allocated aspect ratio. The script only uses compact mark files under `utility-icons-only/` for technical browser/OS slots where complete brand text cannot be read.

The script creates only derived SVG, PDF, PNG, ICO copies, and font-container conversions. It does not introduce a new logo, runtime dependency, remote request, CDN, Manus resource, or live-application change. The added social and print canvases preserve approved vector geometry without stretching it.

## Rebuild sequence

Run the core master generator first, then the export generator:

```bash
python3 brand-packages/2026-document-stack-complete-identity/source/build_document_stack_brand_assets.py
python3 brand-packages/2026-document-stack-complete-identity/source/build_platform_and_print_exports.py
python3 brand-packages/2026-document-stack-complete-identity/source/validate_complete_brand_package.py
```

After a rebuild, refresh `SHA256SUMS`, inspect representative horizontal/square/light/dark assets, verify SVG/XML and PDF files, test the ZIP, and release the master archive only after those checks pass.

#!/usr/bin/env python3
"""Validate ReadyPackets' consistent full-lockup master brand package.

Run from the repository root after regenerating core and platform/print assets:

    python3 brand-packages/2026-document-stack-complete-identity/source/validate_complete_brand_package.py
"""

from __future__ import annotations

import hashlib
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree

from fontTools.ttLib import TTFont
from PIL import Image

PACKAGE = Path(__file__).resolve().parents[1]
REPO = Path(__file__).resolve().parents[3]
EXPORTS = PACKAGE / "platform-and-print-exports"
LOGOS = PACKAGE / "logo-assets"


def open_image(path: Path, size: tuple[int, int], mode: str) -> Image.Image:
    image = Image.open(path)
    assert image.size == size, (path, image.size, size)
    assert image.mode == mode, (path, image.mode, mode)
    return image


def assert_alpha(image: Image.Image, path: Path) -> None:
    assert image.getchannel("A").getextrema() == (0, 255), path


def assert_full_lockup_identifiers(path: Path, square: bool) -> None:
    raw = path.read_text(encoding="utf-8")
    required = (
        ("document-stack-mark", "square-word-ready", "square-word-packets", "square-gold-divider", "square-slogan")
        if square
        else ("document-stack-mark", "word-ready", "word-packets", "gold-divider", "slogan")
    )
    for identifier in required:
        assert f'id="{identifier}"' in raw, (path, identifier)


def validate_vector_assets() -> int:
    svgs = sorted(EXPORTS.rglob("*.svg"))
    assert len(svgs) == 15, len(svgs)
    for svg in svgs:
        ElementTree.parse(svg)
        raw = svg.read_text(encoding="utf-8")
        assert "<text" not in raw, f"live text in {svg}"
        assert '<title id="title">' in raw and '<desc id="desc">' in raw, f"missing SVG accessibility metadata in {svg}"
        assert 'href="http' not in raw and "url(http" not in raw, f"external reference in {svg}"
        assert not any(line.rstrip() != line for line in raw.splitlines()), f"trailing whitespace in {svg}"
    return len(svgs)


def validate_full_lockup_system() -> None:
    assert not list(LOGOS.glob("*wordmark*")), "legacy wordmark-only logo asset remains"
    assert not list(EXPORTS.rglob("*wordmark*")), "legacy wordmark-only platform export remains"

    for mode in ("light", "dark"):
        horizontal = LOGOS / f"readypackets-document-stack-{mode}.svg"
        square = LOGOS / f"readypackets-document-stack-square-{mode}.svg"
        assert_full_lockup_identifiers(horizontal, square=False)
        assert_full_lockup_identifiers(square, square=True)

        linkedin = EXPORTS / "02-linkedin" / f"readypackets-linkedin-full-lockup-square-{mode}-400x400.svg"
        assert_full_lockup_identifiers(linkedin, square=True)
        open_image(linkedin.with_suffix(".png"), (400, 400), "RGB")

        thumbnail = EXPORTS / "03-thumbnails" / f"readypackets-thumbnail-full-lockup-square-{mode}-128x128.svg"
        assert_full_lockup_identifiers(thumbnail, square=True)
        open_image(thumbnail.with_suffix(".png"), (128, 128), "RGB")
        open_image(EXPORTS / "03-thumbnails" / f"readypackets-thumbnail-full-lockup-square-{mode}-256x256.png", (256, 256), "RGB")


def validate_platform_assets() -> None:
    for mode in ("light", "dark"):
        masters = EXPORTS / "01-full-size-masters"
        horizontal = open_image(masters / f"readypackets-full-lockup-horizontal-{mode}-8192w-transparent.png", (8192, 2265), "RGBA")
        square = open_image(masters / f"readypackets-full-lockup-square-{mode}-4096x4096-transparent.png", (4096, 4096), "RGBA")
        assert_alpha(horizontal, Path(horizontal.filename))
        assert_alpha(square, Path(square.filename))
        for composition in ("horizontal", "square"):
            assert (masters / f"readypackets-full-lockup-{composition}-{mode}-vector.svg").exists()
            assert (masters / f"readypackets-full-lockup-{composition}-{mode}-vector.pdf").read_bytes().startswith(b"%PDF-")

        expected_images = (
            (EXPORTS / "04-web-email-and-app" / "website-header" / f"readypackets-full-lockup-horizontal-{mode}-300x90.png", (300, 90), "RGBA"),
            (EXPORTS / "04-web-email-and-app" / "website-header" / f"readypackets-full-lockup-horizontal-{mode}-500x150.png", (500, 150), "RGBA"),
            (EXPORTS / "04-web-email-and-app" / "email-signature" / f"readypackets-full-lockup-horizontal-{mode}-300x90.png", (300, 90), "RGBA"),
            (EXPORTS / "04-web-email-and-app" / "website-hero" / f"readypackets-full-lockup-horizontal-{mode}-500x138.png", (500, 138), "RGBA"),
            (EXPORTS / "05-social-profiles-and-covers" / "profile-images" / f"readypackets-full-lockup-square-{mode}-180x180.png", (180, 180), "RGB"),
            (EXPORTS / "05-social-profiles-and-covers" / "profile-images" / f"readypackets-full-lockup-square-{mode}-800x800.png", (800, 800), "RGB"),
            (EXPORTS / "05-social-profiles-and-covers" / "cover-images" / f"readypackets-full-lockup-horizontal-{mode}-820x312.png", (820, 312), "RGB"),
        )
        for path, size, color_mode in expected_images:
            open_image(path, size, color_mode)

        for size in (512, 192, 180, 152):
            open_image(EXPORTS / "04-web-email-and-app" / "full-square-app-and-launch" / f"readypackets-full-lockup-square-{mode}-{size}x{size}.png", (size, size), "RGB")

        print_images = (
            ("business-cards", f"readypackets-full-lockup-horizontal-{mode}-450x193-300dpi.png", (450, 193)),
            ("letterhead-and-invoices", f"readypackets-full-lockup-horizontal-{mode}-600x180-300dpi.png", (600, 180)),
            ("tshirts", f"readypackets-tshirt-pocket-full-lockup-horizontal-{mode}-1313x363-300dpi.png", (1313, 363)),
            ("tshirts", f"readypackets-tshirt-large-full-lockup-horizontal-{mode}-4200x4500-300dpi.png", (4200, 4500)),
            ("hats", f"readypackets-hat-full-lockup-horizontal-{mode}-1050x290-300dpi.png", (1050, 290)),
            ("mugs", f"readypackets-mug-full-lockup-horizontal-{mode}-2250x622-300dpi.png", (2250, 622)),
            ("tote-bags", f"readypackets-tote-full-lockup-horizontal-{mode}-4200x4800-300dpi.png", (4200, 4800)),
        )
        for folder, filename, size in print_images:
            path = EXPORTS / "06-print-300dpi" / folder / filename
            image = open_image(path, size, "RGBA")
            xdpi, ydpi = image.info.get("dpi", (0, 0))
            assert abs(xdpi - 300) < 1 and abs(ydpi - 300) < 1, (path, image.info.get("dpi"))
            assert_alpha(image, path)

        # Explicitly isolated technical utility icons are expected to be compact.
        for size in (512, 192, 48, 32, 16):
            open_image(EXPORTS / "04-web-email-and-app" / "utility-icons-only" / f"readypackets-utility-mark-{mode}-{size}x{size}.png", (size, size), "RGBA")

    utility = EXPORTS / "04-web-email-and-app" / "utility-icons-only"
    for size in (512, 192, 180, 152):
        open_image(utility / f"readypackets-utility-app-icon-navy-{size}x{size}.png", (size, size), "RGB")
    open_image(utility / "readypackets-utility-app-icon-maskable-512x512.png", (512, 512), "RGB")
    with Image.open(utility / "readypackets-utility-favicon-multiresolution.ico") as favicon:
        required = {(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)}
        assert required.issubset(set(favicon.ico.sizes())), favicon.ico.sizes()


def validate_fonts_and_book() -> None:
    fonts = EXPORTS / "fonts"
    license_text = (fonts / "OFL.txt").read_text(encoding="utf-8")
    assert "SIL OPEN FONT LICENSE Version 1.1" in license_text
    assert "Copyright (c) 2016 The Inter Project Authors" in license_text
    for weight, name in (("400", "Inter-Regular"), ("500", "Inter-Medium"), ("600", "Inter-SemiBold"), ("700", "Inter-Bold")):
        source = REPO / "client" / "public" / "fonts" / f"inter-{weight}.woff2"
        delivered = fonts / "webfonts-woff2" / source.name
        assert hashlib.sha256(source.read_bytes()).digest() == hashlib.sha256(delivered.read_bytes()).digest(), delivered
        desktop = TTFont(fonts / "desktop-ttf" / f"{name}.ttf")
        assert desktop.flavor is None and len(desktop.getGlyphOrder()) > 100, desktop
    book = PACKAGE / "docs" / "ReadyPackets_Document_Stack_Brand_Book_2026-10-15.pdf"
    assert book.read_bytes().startswith(b"%PDF-"), book


def write_asset_manifest() -> tuple[int, int]:
    files = sorted(
        path.relative_to(PACKAGE).as_posix()
        for path in PACKAGE.rglob("*")
        if path.is_file() and path.name not in {"SHA256SUMS", "ASSET_MANIFEST.md"}
    )
    areas = Counter(path.split("/", 1)[0] for path in files)
    export_files = [item for item in files if item.startswith("platform-and-print-exports/")]
    export_areas = Counter(item.split("/", 2)[1] for item in export_files)
    lines = [
        "# Complete Brand Identity Asset Manifest",
        "",
        "**Package:** ReadyPackets Complete Brand Identity — Document-Stack Consistent Full-Lockup System",
        "**Version:** 2026.10.15.2",
        f"**Inventory scope:** Totals and the complete file list exclude this catalog and `SHA256SUMS`; the full package includes {len(files) + 2} files.",
        "",
        "## Consistency policy",
        "",
        "Every customer-facing logo file contains the Document-Stack symbol, ReadyPackets™ name, Gold divider, and Your Business, Professionally Packeted!™ slogan. Horizontal and square lockups use identical components. The compact mark appears only in separately labeled `utility-icons-only/` technical files for browser/OS dimensions that cannot legibly display the full identity.",
        "",
        "## Inventory summary",
        "",
        "| Area | Files | Primary contents |",
        "| --- | ---: | --- |",
        f"| `logo-assets/` | {areas['logo-assets']} | Tight horizontal and square light/dark full lockups |",
        f"| `icons/` | {areas['icons']} | Technical utility marks, PWA/native/browser icon family, favicon |",
        f"| `platform-and-print-exports/` | {areas['platform-and-print-exports']} | Full-size, LinkedIn, thumbnail, digital, social, print, utility, and font delivery files |",
        f"| `previews/` | {areas['previews']} | Approved horizontal/square light/dark review presentations |",
        f"| `docs/` | {areas['docs']} | Brand Book PDF, full-lockup standards, rollout, tokens, and sources |",
        f"| `source/` | {areas['source']} | Reproducible master/export generators and full-lockup validator |",
        f"| `templates/` | {areas['templates']} | Full-lockup email, social/avatar/banner, and public metadata templates |",
        f"| **Total** | **{len(files)}** | Versioned complete identity materials |",
        "",
        "## Platform and print library",
        "",
        "| Delivery subfolder | Files | Purpose |",
        "| --- | ---: | --- |",
        f"| `01-full-size-masters/` | {export_areas['01-full-size-masters']} | Horizontal/square SVG/PDF masters and high-resolution transparent PNGs |",
        f"| `02-linkedin/` | {export_areas['02-linkedin']} | 400 × 400 light/dark full square lockups |",
        f"| `03-thumbnails/` | {export_areas['03-thumbnails']} | 128/256 px light/dark full square lockups |",
        f"| `04-web-email-and-app/` | {export_areas['04-web-email-and-app']} | Full headers/email/app-launch assets and separately labeled utility icons |",
        f"| `05-social-profiles-and-covers/` | {export_areas['05-social-profiles-and-covers']} | Full square profile images and full horizontal cover assets |",
        f"| `06-print-300dpi/` | {export_areas['06-print-300dpi']} | Full horizontal transparent 300-DPI business, stationery, apparel, mug, and tote files |",
        f"| `fonts/` | {export_areas['fonts']} | Inter WOFF2/TTF files and SIL Open Font License text |",
        "",
        "## Primary production files",
        "",
        "| Use case | Asset |",
        "| --- | --- |",
        "| Light horizontal logo | `logo-assets/readypackets-document-stack-light.svg` |",
        "| Dark horizontal logo | `logo-assets/readypackets-document-stack-dark.svg` |",
        "| Light square logo | `logo-assets/readypackets-document-stack-square-light.svg` |",
        "| Dark square logo | `logo-assets/readypackets-document-stack-square-dark.svg` |",
        "| LinkedIn company profile | `platform-and-print-exports/02-linkedin/*-full-lockup-square-400x400.png` |",
        "| Browser favicon | `platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-favicon-multiresolution.ico` |",
        "| Brand Book PDF | `docs/ReadyPackets_Document_Stack_Brand_Book_2026-10-15.pdf` |",
        "| Font delivery | `platform-and-print-exports/fonts/` |",
        "",
        "## Integrity",
        "",
        "Every file below is covered by the adjacent `SHA256SUMS` release manifest, except the checksum file itself. Verify after download with `sha256sum -c SHA256SUMS` from this package directory.",
        "",
        "## Complete file list",
        "",
        "```text",
        *files,
        "```",
        "",
    ]
    (PACKAGE / "docs" / "ASSET_MANIFEST.md").write_text("\n".join(lines), encoding="utf-8")
    return len(files), len(export_files)


def main() -> None:
    svg_count = validate_vector_assets()
    validate_full_lockup_system()
    validate_platform_assets()
    validate_fonts_and_book()
    file_count, export_count = write_asset_manifest()
    print(f"VALIDATION PASS: {svg_count} export SVGs; {export_count} platform/print files; {file_count} pre-manifest package files.")


if __name__ == "__main__":
    main()

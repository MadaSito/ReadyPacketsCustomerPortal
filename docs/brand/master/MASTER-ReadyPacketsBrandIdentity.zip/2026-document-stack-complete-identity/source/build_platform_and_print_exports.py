#!/usr/bin/env python3
"""Build consistent ReadyPackets platform and print assets from full lockup masters.

Every customer-facing logo export includes the Document-Stack symbol, ReadyPackets™,
the Gold divider, and Your Business, Professionally Packeted!™. The only compact
mark assets are explicitly named utility icons for operating-system/browser contexts
where a slogan cannot be legibly rendered (for example, a 16 px favicon).

Run from the repository root:

    python3 brand-packages/2026-document-stack-complete-identity/source/build_platform_and_print_exports.py
"""

from __future__ import annotations

import importlib.util
import shutil
from pathlib import Path

import cairosvg
from fontTools.ttLib import TTFont
from PIL import Image

PACKAGE = Path(__file__).resolve().parents[1]
REPO = Path(__file__).resolve().parents[3]
LOGOS = PACKAGE / "logo-assets"
ICONS = PACKAGE / "icons"
FONTS = REPO / "client" / "public" / "fonts"
EXPORTS = PACKAGE / "platform-and-print-exports"


def load_core():
    source = PACKAGE / "source" / "build_document_stack_brand_assets.py"
    spec = importlib.util.spec_from_file_location("document_stack_brand", source)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load brand source: {source}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


CORE = load_core()


def write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding="utf-8")


def render_png(source: Path, destination: Path, width: int, height: int, dpi: int | None = None) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    cairosvg.svg2png(url=str(source), write_to=str(destination), output_width=width, output_height=height)
    if dpi:
        with Image.open(destination) as image:
            image.save(destination, dpi=(dpi, dpi), optimize=True)


def render_pdf(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    cairosvg.svg2pdf(url=str(source), write_to=str(destination))


def copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def square_full_surface_svg(mode: str) -> str:
    background = CORE.WHITE if mode == "light" else CORE.NAVY
    return CORE.square_full_lockup_svg(mode, background=background)


def full_canvas_svg(mode: str, width: int, height: int, title: str, description: str) -> str:
    """Place the horizontal full lockup without stretching it in a transparent print canvas."""
    content = CORE.full_lockup_content(mode)
    return "\n".join(
        [
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 200 2460 680" preserveAspectRatio="xMidYMid meet" role="img" aria-labelledby="title desc">',
            f'  <title id="title">{title}</title>',
            f'  <desc id="desc">{description}</desc>',
            *[f'  {line}'.rstrip() for line in content.splitlines()],
            "</svg>",
            "",
        ]
    )


def social_cover_svg(mode: str) -> str:
    """Create a tightly framed 820 × 312 social cover from the full horizontal lockup."""
    dark = mode == "dark"
    background = CORE.NAVY if dark else CORE.WHITE
    content = f'<g transform="translate(40 -4) scale(0.565)">{CORE.full_lockup_content(mode)}</g>'
    return "\n".join(
        [
            '<svg xmlns="http://www.w3.org/2000/svg" width="820" height="312" viewBox="0 0 1600 640" preserveAspectRatio="xMidYMid slice" role="img" aria-labelledby="title desc">',
            f'  <title id="title">ReadyPackets full logo social cover for {mode} placement</title>',
            '  <desc id="desc">ReadyPackets full lockup with the document stack, trademarked company name, and trademarked slogan.</desc>',
            f'  <rect width="1600" height="640" fill="{background}"/>',
            f'  {content}',
            '</svg>',
            '',
        ]
    )


def make_font_exports() -> None:
    font_dir = EXPORTS / "fonts"
    web_dir = font_dir / "webfonts-woff2"
    desktop_dir = font_dir / "desktop-ttf"
    weights = {
        "400": "Inter-Regular",
        "500": "Inter-Medium",
        "600": "Inter-SemiBold",
        "700": "Inter-Bold",
    }
    for weight, name in weights.items():
        source = FONTS / f"inter-{weight}.woff2"
        target_web = web_dir / source.name
        target_web.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target_web)

        font = TTFont(source)
        font.flavor = None
        target_ttf = desktop_dir / f"{name}.ttf"
        target_ttf.parent.mkdir(parents=True, exist_ok=True)
        font.save(target_ttf)


def reset_generated_export_folders() -> None:
    """Remove stale legacy wordmark/compact social exports before rebuilding."""
    for name in (
        "01-full-size-masters",
        "02-linkedin",
        "03-thumbnails",
        "04-web-email-and-app",
        "05-social-profiles-and-covers",
        "06-print-300dpi",
    ):
        folder = EXPORTS / name
        if folder.exists():
            shutil.rmtree(folder)
        folder.mkdir(parents=True, exist_ok=True)


def main() -> None:
    EXPORTS.mkdir(parents=True, exist_ok=True)
    reset_generated_export_folders()

    masters = EXPORTS / "01-full-size-masters"
    linkedin = EXPORTS / "02-linkedin"
    thumbnails = EXPORTS / "03-thumbnails"
    digital = EXPORTS / "04-web-email-and-app"
    social = EXPORTS / "05-social-profiles-and-covers"
    print_exports = EXPORTS / "06-print-300dpi"

    for mode in ("light", "dark"):
        horizontal_svg = LOGOS / f"readypackets-document-stack-{mode}.svg"
        square_svg = LOGOS / f"readypackets-document-stack-square-{mode}.svg"

        # The full horizontal and square masters deliberately share every visual
        # component; only composition changes to make all content readable.
        copy(horizontal_svg, masters / f"readypackets-full-lockup-horizontal-{mode}-vector.svg")
        copy(square_svg, masters / f"readypackets-full-lockup-square-{mode}-vector.svg")
        render_pdf(horizontal_svg, masters / f"readypackets-full-lockup-horizontal-{mode}-vector.pdf")
        render_pdf(square_svg, masters / f"readypackets-full-lockup-square-{mode}-vector.pdf")
        render_png(horizontal_svg, masters / f"readypackets-full-lockup-horizontal-{mode}-8192w-transparent.png", 8192, 2265)
        render_png(square_svg, masters / f"readypackets-full-lockup-square-{mode}-4096x4096-transparent.png", 4096, 4096)

        # Full horizontal lockups for website and email; no wordmark-only logos.
        render_png(horizontal_svg, digital / "website-header" / f"readypackets-full-lockup-horizontal-{mode}-300x90.png", 300, 90)
        render_png(horizontal_svg, digital / "website-header" / f"readypackets-full-lockup-horizontal-{mode}-500x150.png", 500, 150)
        render_png(horizontal_svg, digital / "email-signature" / f"readypackets-full-lockup-horizontal-{mode}-300x90.png", 300, 90)
        render_png(horizontal_svg, digital / "website-hero" / f"readypackets-full-lockup-horizontal-{mode}-500x138.png", 500, 138)

        # Full square lockups for LinkedIn, thumbnails, app launch screens, and social profiles.
        square_surface = linkedin / f"readypackets-linkedin-full-lockup-square-{mode}-400x400.svg"
        write_text(square_surface, square_full_surface_svg(mode))
        render_png(square_surface, linkedin / f"readypackets-linkedin-full-lockup-square-{mode}-400x400.png", 400, 400)

        thumb_surface = thumbnails / f"readypackets-thumbnail-full-lockup-square-{mode}-128x128.svg"
        write_text(thumb_surface, square_full_surface_svg(mode))
        render_png(thumb_surface, thumbnails / f"readypackets-thumbnail-full-lockup-square-{mode}-128x128.png", 128, 128)
        render_png(thumb_surface, thumbnails / f"readypackets-thumbnail-full-lockup-square-{mode}-256x256.png", 256, 256)

        for size in (180, 800):
            render_png(square_surface, social / "profile-images" / f"readypackets-full-lockup-square-{mode}-{size}x{size}.png", size, size)
        cover_svg = social / "cover-images" / f"readypackets-full-lockup-horizontal-{mode}-820x312.svg"
        write_text(cover_svg, social_cover_svg(mode))
        render_png(cover_svg, social / "cover-images" / f"readypackets-full-lockup-horizontal-{mode}-820x312.png", 820, 312)

        # Full lockup print assets. Transparent print canvases are intentional for vendor placement.
        render_png(horizontal_svg, print_exports / "business-cards" / f"readypackets-full-lockup-horizontal-{mode}-450x193-300dpi.png", 450, 193, dpi=300)
        render_png(horizontal_svg, print_exports / "letterhead-and-invoices" / f"readypackets-full-lockup-horizontal-{mode}-600x180-300dpi.png", 600, 180, dpi=300)
        render_png(horizontal_svg, print_exports / "tshirts" / f"readypackets-tshirt-pocket-full-lockup-horizontal-{mode}-1313x363-300dpi.png", 1313, 363, dpi=300)
        render_png(horizontal_svg, print_exports / "hats" / f"readypackets-hat-full-lockup-horizontal-{mode}-1050x290-300dpi.png", 1050, 290, dpi=300)
        render_png(horizontal_svg, print_exports / "mugs" / f"readypackets-mug-full-lockup-horizontal-{mode}-2250x622-300dpi.png", 2250, 622, dpi=300)

        shirt_svg = print_exports / "tshirts" / f"readypackets-tshirt-large-full-lockup-horizontal-{mode}-4200x4500-300dpi.svg"
        write_text(
            shirt_svg,
            full_canvas_svg(mode, 4200, 4500, f"ReadyPackets full logo for {mode} large T-shirt placement", "Transparent 14 by 15 inch 300 DPI decoration canvas containing the full ReadyPackets lockup."),
        )
        render_png(shirt_svg, print_exports / "tshirts" / f"readypackets-tshirt-large-full-lockup-horizontal-{mode}-4200x4500-300dpi.png", 4200, 4500, dpi=300)

        tote_svg = print_exports / "tote-bags" / f"readypackets-tote-full-lockup-horizontal-{mode}-4200x4800-300dpi.svg"
        write_text(
            tote_svg,
            full_canvas_svg(mode, 4200, 4800, f"ReadyPackets full logo for {mode} tote bag placement", "Transparent 14 by 16 inch 300 DPI decoration canvas containing the full ReadyPackets lockup."),
        )
        render_png(tote_svg, print_exports / "tote-bags" / f"readypackets-tote-full-lockup-horizontal-{mode}-4200x4800-300dpi.png", 4200, 4800, dpi=300)

        for size in (512, 192, 180, 152):
            render_png(square_surface, digital / "full-square-app-and-launch" / f"readypackets-full-lockup-square-{mode}-{size}x{size}.png", size, size)

    # These operating-system/browser asset files are not customer-facing logo lockups.
    # They retain only the symbol because company name and slogan cannot be legibly
    # rendered in 16–48px technical icon slots.
    for mode in ("light", "dark"):
        for size in (512, 192, 48, 32, 16):
            destination = digital / "utility-icons-only" / f"readypackets-utility-mark-{mode}-{size}x{size}.png"
            source = ICONS / f"readypackets-document-stack-mark-{mode}-{size}.png"
            if source.exists():
                copy(source, destination)
            else:
                render_png(ICONS / f"readypackets-document-stack-mark-{mode}.svg", destination, size, size)
    for size in (512, 192, 180, 152):
        copy(ICONS / f"readypackets-app-icon-{size}.png", digital / "utility-icons-only" / f"readypackets-utility-app-icon-navy-{size}x{size}.png")
    copy(ICONS / "readypackets-app-icon-maskable.svg", digital / "utility-icons-only" / "readypackets-utility-app-icon-maskable-vector.svg")
    copy(ICONS / "readypackets-app-icon-maskable-512.png", digital / "utility-icons-only" / "readypackets-utility-app-icon-maskable-512x512.png")
    copy(ICONS / "readypackets-favicon.ico", digital / "utility-icons-only" / "readypackets-utility-favicon-multiresolution.ico")

    make_font_exports()
    print(f"Built consistent full-lockup platform and print exports under {EXPORTS}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Build ReadyPackets' self-hosted Document-Stack visual identity assets.

All logo SVGs convert the repository's local Inter font glyphs to path outlines.
The exported SVG, PNG, and ICO assets therefore require no remote font, CDN,
Manus service, or browser-time network dependency.

Run from a cloned repository root:
    python3 brand-packages/2026-document-stack-complete-identity/source/build_document_stack_brand_assets.py
"""

from __future__ import annotations

from pathlib import Path

import cairosvg
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.ttLib import TTFont
from PIL import Image

PACKAGE = Path(__file__).resolve().parents[1]
REPO = Path(__file__).resolve().parents[3]
FONTS = REPO / "client" / "public" / "fonts"
LOGOS = PACKAGE / "logo-assets"
ICONS = PACKAGE / "icons"
PREVIEWS = PACKAGE / "previews"
TEMPLATES = PACKAGE / "templates"

# Canonical ReadyPackets palette from shared/brand.ts.
NAVY = "#0D1B2A"
NAVY_RAISED = "#12263A"
TEAL = "#20A090"
TEAL_DARK = "#1A7A6E"
TEAL_LIGHT = "#2EC4B6"
GOLD = "#C9A84C"
GRAY_DARK = "#4A5568"
WHITE = "#FFFFFF"


class OutlinedFont:
    """Encode local WOFF2 glyphs as SVG paths, eliminating runtime font loading."""

    def __init__(self, font_file: Path) -> None:
        self.font = TTFont(font_file)
        self.glyphs = self.font.getGlyphSet()
        self.cmap = self.font.getBestCmap()
        self.hmtx = self.font["hmtx"]
        self.upm = self.font["head"].unitsPerEm

    def width(self, text: str, size: float, tracking: float = 0) -> float:
        return sum(self.hmtx[self.cmap[ord(ch)]][0] * size / self.upm for ch in text) + tracking * max(0, len(text) - 1)

    def paths(
        self,
        *,
        identifier: str,
        text: str,
        x: float,
        baseline: float,
        size: float,
        fill: str,
        tracking: float = 0,
    ) -> str:
        cursor = x
        scale = size / self.upm
        parts = [f'<g id="{identifier}" fill="{fill}" aria-label="{text}">']
        for ch in text:
            glyph_name = self.cmap[ord(ch)]
            pen = SVGPathPen(self.glyphs)
            self.glyphs[glyph_name].draw(pen)
            commands = pen.getCommands()
            if commands:
                parts.append(
                    f'<path d="{commands}" transform="translate({cursor:.3f} {baseline:.3f}) scale({scale:.9f} {-scale:.9f})"/>'
                )
            cursor += self.hmtx[glyph_name][0] * scale + tracking
        parts.append("</g>")
        return "\n    ".join(parts)


BOLD = OutlinedFont(FONTS / "inter-700.woff2")
MEDIUM = OutlinedFont(FONTS / "inter-500.woff2")


def document_stack_geometry(mode: str) -> str:
    """Native vector geometry for the selected ReadyPackets document-stack mark."""
    dark = mode == "dark"
    rear = "#164F70" if dark else NAVY
    middle = "#1A587B" if dark else NAVY_RAISED
    teal = TEAL_LIGHT if dark else TEAL
    cutout = NAVY if dark else WHITE
    return f'''<g id="document-stack-mark">
      <path d="M0 95L222 0Q241 -8 241 15V83L69 177Q53 185 53 205V351L0 381Z" fill="{rear}"/>
      <path d="M87 145L310 47Q328 39 328 61V129L156 223Q140 231 140 251V397L87 427Z" fill="{middle}"/>
      <path d="M179 189L395 94Q415 85 415 108V271Q415 288 399 297L179 418Z" fill="{teal}"/>
      <path d="M72 170L249 74L303 101L126 198Q112 206 112 223V316L72 338Z" fill="{cutout}"/>
      <path d="M160 219L337 122L385 148L208 245Q194 253 194 270V365L160 384Z" fill="{cutout}"/>
    </g>'''


def full_lockup_content(mode: str) -> str:
    """Return full lockup content in the standard 2688×1152 coordinate system."""
    dark = mode == "dark"
    ready_fill = WHITE if dark else NAVY
    packets_fill = TEAL_LIGHT if dark else TEAL
    tm_fill = WHITE if dark else NAVY
    tagline_fill = WHITE if dark else TEAL_DARK
    word_x, word_size, baseline, tracking = 660, 244, 555, -4.5
    ready_word, packets_word = "Ready", "Packets"
    ready_width = BOLD.width(ready_word, word_size, tracking)
    packets_width = BOLD.width(packets_word, word_size, tracking)
    word_width = ready_width + packets_width
    word_end = word_x + word_width

    slogan = "Your Business, Professionally Packeted!"
    slogan_size, slogan_tracking, slogan_tm_size = 76, -1.25, 33
    slogan_width = MEDIUM.width(slogan, slogan_size, slogan_tracking)
    slogan_tm_width = MEDIUM.width("™", slogan_tm_size)
    slogan_total_width = slogan_width + 7 + slogan_tm_width
    slogan_x = word_x + (word_width - slogan_total_width) / 2
    slogan_tm_x = slogan_x + slogan_width + 7

    return f'''<g id="full-document-stack-lockup">
    <g transform="translate(104 280)">{document_stack_geometry(mode)}</g>
    {BOLD.paths(identifier="word-ready", text=ready_word, x=word_x, baseline=baseline, size=word_size, fill=ready_fill, tracking=tracking)}
    {BOLD.paths(identifier="word-packets", text=packets_word, x=word_x + ready_width, baseline=baseline, size=word_size, fill=packets_fill, tracking=tracking)}
    {MEDIUM.paths(identifier="wordmark-trademark", text="™", x=word_end + 13, baseline=374, size=53, fill=tm_fill)}
    <path id="gold-divider" d="M{word_x:.3f} 657H{word_end:.3f}" stroke="{GOLD}" stroke-width="14" stroke-linecap="round"/>
    {MEDIUM.paths(identifier="slogan", text=slogan, x=slogan_x, baseline=782, size=slogan_size, fill=tagline_fill, tracking=slogan_tracking)}
    {MEDIUM.paths(identifier="slogan-trademark", text="™", x=slogan_tm_x, baseline=725, size=slogan_tm_size, fill=tagline_fill)}
  </g>'''


def square_full_lockup_content(mode: str) -> str:
    """Return the full brand lockup in a tightly framed square social/profile composition."""
    dark = mode == "dark"
    ready_fill = WHITE if dark else NAVY
    packets_fill = TEAL_LIGHT if dark else TEAL
    tm_fill = WHITE if dark else NAVY
    tagline_fill = WHITE if dark else TEAL_DARK
    word_size, word_tracking = 132, -2.5
    ready_word, packets_word = "Ready", "Packets"
    ready_width = BOLD.width(ready_word, word_size, word_tracking)
    packets_width = BOLD.width(packets_word, word_size, word_tracking)
    word_width = ready_width + packets_width
    word_x = (1024 - word_width) / 2
    word_end = word_x + word_width

    slogan = "Your Business, Professionally Packeted!"
    slogan_size, slogan_tracking, slogan_tm_size = 46, -0.7, 20
    slogan_width = MEDIUM.width(slogan, slogan_size, slogan_tracking)
    slogan_tm_width = MEDIUM.width("™", slogan_tm_size)
    slogan_total_width = slogan_width + 5 + slogan_tm_width
    slogan_x = (1024 - slogan_total_width) / 2
    slogan_tm_x = slogan_x + slogan_width + 5

    return f'''<g id="square-full-document-stack-lockup">
    <g transform="translate(304 74) scale(1.00)">{document_stack_geometry(mode)}</g>
    {BOLD.paths(identifier="square-word-ready", text=ready_word, x=word_x, baseline=674, size=word_size, fill=ready_fill, tracking=word_tracking)}
    {BOLD.paths(identifier="square-word-packets", text=packets_word, x=word_x + ready_width, baseline=674, size=word_size, fill=packets_fill, tracking=word_tracking)}
    {MEDIUM.paths(identifier="square-wordmark-trademark", text="™", x=word_end + 8, baseline=575, size=31, fill=tm_fill)}
    <path id="square-gold-divider" d="M{word_x:.3f} 744H{word_end:.3f}" stroke="{GOLD}" stroke-width="10" stroke-linecap="round"/>
    {MEDIUM.paths(identifier="square-slogan", text=slogan, x=slogan_x, baseline=838, size=slogan_size, fill=tagline_fill, tracking=slogan_tracking)}
    {MEDIUM.paths(identifier="square-slogan-trademark", text="™", x=slogan_tm_x, baseline=803, size=slogan_tm_size, fill=tagline_fill)}
  </g>'''


def svg_document(
    title: str,
    description: str,
    width: int,
    height: int,
    content: str,
    background: str | None = None,
    view_box: tuple[int, int, int, int] | None = None,
) -> str:
    view_x, view_y, view_width, view_height = view_box or (0, 0, width, height)
    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="{view_x} {view_y} {view_width} {view_height}" role="img" aria-labelledby="title desc">',
        f'  <title id="title">{title}</title>',
        f'  <desc id="desc">{description}</desc>',
    ]
    if background:
        lines.append(f'  <rect x="{view_x}" y="{view_y}" width="{view_width}" height="{view_height}" fill="{background}"/>')
    lines.extend(f'  {line}'.rstrip() for line in content.splitlines())
    lines.append("</svg>")
    return "\n".join(lines) + "\n"


def full_lockup_svg(mode: str, background: str | None = None) -> str:
    return svg_document(
        f"ReadyPackets Document-Stack full logo for {mode} placement",
        "A layered business-document mark, the trademarked ReadyPackets name, and the trademarked slogan Your Business, Professionally Packeted.",
        2460,
        680,
        full_lockup_content(mode),
        background,
        view_box=(0, 200, 2460, 680),
    )


def square_full_lockup_svg(mode: str, background: str | None = None) -> str:
    return svg_document(
        f"ReadyPackets Document-Stack square full logo for {mode} placement",
        "A square full brand lockup with the layered document symbol, trademarked ReadyPackets name, and trademarked slogan Your Business, Professionally Packeted.",
        1024,
        1024,
        square_full_lockup_content(mode),
        background,
    )


def icon_svg(mode: str, background: str | None = None, maskable: bool = False) -> str:
    """Return app/fav icon SVG; maskable variant preserves a larger safe margin."""
    if maskable:
        transform = "translate(190 238) scale(1.58)"
    else:
        transform = "translate(112 180) scale(2.03)"
    content = f'<g transform="{transform}">{document_stack_geometry(mode)}</g>'
    return svg_document(
        f"ReadyPackets Document-Stack compact mark for {mode} placement",
        "The ReadyPackets layered business-document mark.",
        1024,
        1024,
        content,
        background,
    )


def social_banner_svg(mode: str) -> str:
    dark = mode == "dark"
    background = NAVY if dark else WHITE
    content = f'<g transform="translate(40 -4) scale(0.565)">{full_lockup_content(mode)}</g>'
    return svg_document(
        f"ReadyPackets Document-Stack social banner for {mode} placement",
        "ReadyPackets document-stack brand banner with trademarked logo and slogan.",
        1600,
        640,
        content,
        background,
    )


def render_svg(source: Path, destination: Path, width: int, height: int) -> None:
    cairosvg.svg2png(url=str(source), write_to=str(destination), output_width=width, output_height=height)


def opaque_preview(source: Path, destination: Path, background: str) -> None:
    image = Image.open(source).convert("RGBA")
    preview = Image.new("RGBA", image.size, background)
    preview.alpha_composite(image)
    preview.convert("RGB").save(destination, optimize=True)


def main() -> None:
    for folder in (LOGOS, ICONS, PREVIEWS, TEMPLATES):
        folder.mkdir(parents=True, exist_ok=True)

    # Retire previous wordmark-only outputs: the current brand-owner direction
    # requires every customer-facing logo file to carry icon, name, and slogan.
    for legacy in LOGOS.glob("*wordmark*"):
        legacy.unlink()

    # Full identity lockups: tightly framed transparent horizontal and square masters.
    for mode in ("light", "dark"):
        svg = LOGOS / f"readypackets-document-stack-{mode}.svg"
        png = LOGOS / f"readypackets-document-stack-{mode}-transparent.png"
        svg.write_text(full_lockup_svg(mode), encoding="utf-8")
        render_svg(svg, png, 2460, 680)
        opaque_preview(png, PREVIEWS / f"readypackets-document-stack-{mode}-preview.png", WHITE if mode == "light" else NAVY)

        square_svg = LOGOS / f"readypackets-document-stack-square-{mode}.svg"
        square_png = LOGOS / f"readypackets-document-stack-square-{mode}-transparent.png"
        square_svg.write_text(square_full_lockup_svg(mode), encoding="utf-8")
        render_svg(square_svg, square_png, 1024, 1024)
        opaque_preview(square_png, PREVIEWS / f"readypackets-document-stack-square-{mode}-preview.png", WHITE if mode == "light" else NAVY)

    # Compact logo marks for use on a matching surface.
    for mode in ("light", "dark"):
        svg = ICONS / f"readypackets-document-stack-mark-{mode}.svg"
        svg.write_text(icon_svg(mode), encoding="utf-8")
        for size in (1024, 512, 256, 180, 152, 144, 128, 96, 72, 64, 48, 32, 16):
            render_svg(svg, ICONS / f"readypackets-document-stack-mark-{mode}-{size}.png", size, size)

    # A navy-backed app icon is stable in browser, PWA, iOS, Android, and social-avatar surfaces.
    app_svg = ICONS / "readypackets-app-icon.svg"
    app_svg.write_text(icon_svg("dark", background=NAVY), encoding="utf-8")
    for size in (1024, 512, 256, 192, 180, 152):
        render_svg(app_svg, ICONS / f"readypackets-app-icon-{size}.png", size, size)
    maskable_svg = ICONS / "readypackets-app-icon-maskable.svg"
    maskable_svg.write_text(icon_svg("dark", background=NAVY, maskable=True), encoding="utf-8")
    render_svg(maskable_svg, ICONS / "readypackets-app-icon-maskable-512.png", 512, 512)
    Image.open(ICONS / "readypackets-app-icon-256.png").convert("RGBA").save(
        ICONS / "readypackets-favicon.ico",
        sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
    )

    # Social/banner launch assets using the same visual source and color system.
    for mode in ("light", "dark"):
        banner = TEMPLATES / f"readypackets-social-banner-{mode}.svg"
        banner.write_text(social_banner_svg(mode), encoding="utf-8")
        render_svg(banner, TEMPLATES / f"readypackets-social-banner-{mode}.png", 1600, 640)
        social_avatar = TEMPLATES / f"readypackets-social-avatar-full-lockup-square-{mode}.svg"
        social_avatar.write_text(square_full_lockup_svg(mode, background=WHITE if mode == "light" else NAVY), encoding="utf-8")
        render_svg(social_avatar, TEMPLATES / f"readypackets-social-avatar-full-lockup-square-{mode}-1024.png", 1024, 1024)
    legacy_avatar = TEMPLATES / "readypackets-social-avatar-1024.png"
    if legacy_avatar.exists():
        legacy_avatar.unlink()

    print(f"Built complete Document-Stack identity assets under {PACKAGE}")


if __name__ == "__main__":
    main()

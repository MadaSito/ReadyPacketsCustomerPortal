# Source and Rebuild Notes

## Source of truth

`build_document_stack_brand_assets.py` is the editable source for the complete Document-Stack logo family. It creates horizontal and square full lockup SVG/PNG masters, preview PNGs, clearly separated technical utility icons, PWA/app icons, favicons, full-lockup social avatars, and social-banner assets in this package.

The source reads only the ReadyPackets repository’s self-hosted Inter WOFF2 assets and color values maintained in `shared/brand.ts`. It transforms wordmark and slogan glyphs into native SVG path outlines. Final logo files contain no `<text>` element, external CSS, external font, CDN, remote image, Manus service, or runtime JavaScript.

## Rebuild

Run from the repository root:

```bash
python3 brand-packages/2026-document-stack-complete-identity/source/build_document_stack_brand_assets.py
python3 brand-packages/2026-document-stack-complete-identity/source/build_platform_and_print_exports.py
```

The build-only environment requires `fonttools`, `cairosvg`, and `Pillow`. The generated assets themselves have no build-tool or runtime dependency.

## Edit discipline

1. Change only this source script or the documented brand tokens after approval.
2. Regenerate the complete asset family; do not hand-edit one exported PNG.
3. Validate XML, no-live-text, title/description metadata, transparency, full-lockup dimensions, favicon format, light/dark contrast, and checksum manifest.
4. Review horizontal/square full lockups, light/dark surfaces, browser/PWA technical slots, email, LinkedIn, thumbnail, print, and social contexts.
5. Document the versioned decision and issue a new archive.

The ™ glyphs after `ReadyPackets` and after `Your Business, Professionally Packeted!` are separate outlined groups so their placement and scale remain deterministic. Consult qualified counsel before changing a ™ notice to ® or making legal claims about registration.

`build_platform_and_print_exports.py` deterministically renders the approved horizontal and square full lockups into the versioned LinkedIn, thumbnail, website, email, social, print, and font-delivery library under `platform-and-print-exports/`. It also converts the local Inter WOFF2 files to equivalent desktop TTF containers; it does not modify glyphs or the Document-Stack artwork. Technical browser/OS icon files remain separately labeled utility assets because a full wordmark and slogan cannot be legible at favicon dimensions.

# ReadyPackets Complete Brand Identity

**Package version:** 2026.10.15.2
**Identity:** Document-Stack Consistent Full-Lockup System
**Status:** Production candidate pending brand-owner approval and trademark-use review
**Brand owner:** Ready Packets Consulting LLC

## Purpose

This complete self-hosted ReadyPackets package uses one consistent customer-facing logo system: the layered Document-Stack symbol, `ReadyPackets™`, a Gold divider, and `Your Business, Professionally Packeted!™`. Every branded logo file uses those same four components. The only icon-only files are separately labeled technical utility assets for operating-system and browser slots where name and slogan cannot be legibly rendered.

Two approved compositions carry the same full identity:

- **Horizontal full lockup:** headers, email, documents, print, proposals, banners, and wide placements.
- **Square full lockup:** LinkedIn, thumbnails, social profiles, app launch surfaces, and square placements.

## Package map

| Folder | Contents |
| --- | --- |
| `logo-assets/` | Tightly framed horizontal and square light/dark full lockups as outlined SVG and transparent PNG |
| `icons/` | Technical utility marks, PWA/native icon family, and favicon; not customer-facing full logo files |
| `platform-and-print-exports/` | Full-size masters, LinkedIn, thumbnails, web/email/app, social, print, and included-font delivery files |
| `previews/` | Light/dark horizontal and square full-lockup review compositions |
| `docs/` | Brand Book PDF, standards, logo rules, color/type system, voice, digital system, rollout plan, and manifest |
| `source/` | Reproducible local SVG/PNG/ICO generators, validation script, and source notes |
| `templates/` | Full-lockup social/avatar/banner assets, email signature, and brand metadata |

## Start here

1. Read `docs/BRAND_STANDARDS.md` and `docs/LOGO_USAGE.md` before placing any logo.
2. Use `logo-assets/readypackets-document-stack-light.svg` or `...-dark.svg` for a horizontal full logo.
3. Use `logo-assets/readypackets-document-stack-square-light.svg` or `...-dark.svg` for a square full logo.
4. Use `platform-and-print-exports/README.md` to select a ready-to-upload size.
5. Use `docs/DIGITAL_SYSTEM.md`, `docs/tokens.css`, and `docs/tokens.json` for self-hosted product and marketing implementation.
6. Read `docs/BRAND_ROLLOUT.md` before replacing live application assets.

## No runtime external dependency

All supplied logo lettering is converted to local Inter glyph outlines. The assets make no runtime request to a font host, CDN, Manus service, design tool, or other third party. The package includes self-hosted Inter WOFF2 and desktop TTF files with the applicable SIL Open Font License text.

## Important activation boundary

This package does **not** automatically replace live application assets, metadata, favicon/PWA configuration, or `shared/brand.ts`. Adopt it through the coordinated checklist in `docs/BRAND_ROLLOUT.md` after brand-owner approval and trademark-use review.

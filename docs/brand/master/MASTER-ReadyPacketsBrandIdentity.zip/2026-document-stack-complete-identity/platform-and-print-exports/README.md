# ReadyPackets Platform & Print Exports

Every customer-facing logo in this folder is a **full ReadyPackets lockup** with the Document-Stack symbol, `ReadyPackets™`, Gold divider, and `Your Business, Professionally Packeted!™`. The package uses a tight horizontal composition for wide spaces and a tight square composition for square spaces. These compositions have the same components, colors, trademark placement, and hierarchy.

## Select the correct color mode

| Placement surface | Use |
| --- | --- |
| White or very light background | `light` asset — Navy `Ready`, Teal `Packets`, Deep Teal slogan |
| Navy or dark background | `dark` asset — White `Ready`, Teal Light `Packets`, White slogan |

Do not recolor, stretch, rotate, crop, or rebuild the supplied assets.

## Folder map

| Folder | What it contains | Use it for |
| --- | --- | --- |
| `01-full-size-masters/` | Horizontal and square SVG/PDF vector masters; 8,192 px horizontal and 4,096 px square transparent PNGs | Custom resizing, vendors, high-resolution layouts, and long-term source preservation |
| `02-linkedin/` | Light/dark 400 × 400 opaque **full square lockups** | LinkedIn company-profile logo uploads |
| `03-thumbnails/` | Light/dark 128 × 128 and 256 × 256 opaque **full square lockups** | Thumbnails, small previews, and compact listings |
| `04-web-email-and-app/` | Full horizontal header/email/hero assets; full square app and launch assets; clearly separated technical utility icons | Website, email signature, app launch, browser, PWA, and native mobile |
| `05-social-profiles-and-covers/` | Full square profile images and full horizontal 820 × 312 covers | Social profile and cover placements |
| `06-print-300dpi/` | Full horizontal transparent 300-DPI PNG exports for cards, stationery, apparel, hats, mugs, and totes | Print-vendor handoff; use the vector masters whenever a vendor accepts them |
| `fonts/` | Inter web WOFF2 and desktop TTF files with license | Product, website, document, and presentation typography |

## File-size matrix

| Use case | File / canvas size | Composition |
| --- | ---: | --- |
| Unlimited custom scale | SVG/PDF vector | Horizontal or square full lockup |
| High-resolution horizontal logo | 8,192 px wide PNG | Horizontal full lockup |
| High-resolution square logo | 4,096 × 4,096 px PNG | Square full lockup |
| Website header | 300 × 90 and 500 × 150 px | Horizontal full lockup |
| Website hero | 500 × 138 px | Horizontal full lockup |
| Email signature | 300 × 90 px | Horizontal full lockup |
| LinkedIn company profile | 400 × 400 px | Square full lockup |
| Thumbnail | 128 × 128 px; 256 × 256 retina version | Square full lockup |
| Social profile | 180 × 180 and 800 × 800 px | Square full lockup |
| Social cover | 820 × 312 px | Horizontal full lockup |
| Business card | 450 × 193 px at 300 DPI | Horizontal full lockup |
| Letterhead / invoice header | 600 × 180 px at 300 DPI | Horizontal full lockup |
| T-shirt pocket | 1,313 × 363 px at 300 DPI | Horizontal full lockup |
| Large T-shirt decoration | 4,200 × 4,500 px at 300 DPI | Horizontal full lockup centered in a transparent 14 × 15 in canvas |
| Hat | 1,050 × 290 px at 300 DPI | Horizontal full lockup; obtain an embroidery proof before production |
| Mug | 2,250 × 622 px at 300 DPI | Horizontal full lockup |
| Tote bag | 4,200 × 4,800 px at 300 DPI | Horizontal full lockup centered in a transparent 14 × 16 in canvas |

## Technical utility-icon exception

`04-web-email-and-app/utility-icons-only/` contains the compact Document-Stack mark for technical slots such as 16/32/48 px browser favicons, maskable icons, and operating-system app tiles. These files are **not** a separate customer-facing logo family: a company name and full slogan cannot be legibly represented at those technical dimensions. Use the full square app-and-launch files whenever the platform permits a branded square logo.

## Vector and font formats

The package provides native outlined **SVG** and vector **PDF** masters. SVG is the preferred editable vector source for web, print vendors, and Illustrator import. Native `.ai` and `.eps` files are not fabricated because the source SVG/PDF are lossless vectors; a printer or designer requiring a proprietary format can import the supplied SVG/PDF and save it in that system without redrawing the identity.

The included `fonts/` directory contains Inter 4.001 web WOFF2 files and corresponding desktop TTF exports. The logo itself is path-outlined and does not require a font to display. See `fonts/OFL.txt` and `fonts/README.md` before distributing the font files.

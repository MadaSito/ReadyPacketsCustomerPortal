# Included Inter Font Files

The ReadyPackets visual system uses **Inter** for product, web, documents, and supporting brand typography. This folder includes the four locally used weights in two delivery formats:

| Folder | Files | Use |
| --- | --- | --- |
| `webfonts-woff2/` | Regular 400, Medium 500, SemiBold 600, Bold 700 | Self-hosted websites and applications |
| `desktop-ttf/` | Regular, Medium, SemiBold, Bold | Desktop documents, presentations, and approved design workflows |

The supplied WOFF2 files carry Inter name-table metadata identifying **Version 4.001**. The desktop TTFs are format conversions of those same local webfont files; no glyphs were edited. The logo files do not require the font because their lettering is converted into native vector paths.

Inter is included under the **SIL Open Font License, Version 1.1**. Retain `OFL.txt` when redistributing the font files and review the license conditions before modifying or separately distributing them. The authoritative Inter license source is retained in the project record: https://github.com/rsms/inter/blob/master/LICENSE.txt

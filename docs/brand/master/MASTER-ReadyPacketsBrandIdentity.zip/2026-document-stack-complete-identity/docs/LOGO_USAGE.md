# Logo System and Usage Guide

## Full-lockup policy

All customer-facing ReadyPackets logo files use one complete identity: **Document-Stack symbol + ReadyPackets™ + Gold divider + Your Business, Professionally Packeted!™**. The system has two responsive compositions, not separate logo tiers:

- **Horizontal full lockup** for wide placements.
- **Square full lockup** for square placements.

They share the exact same brand components, color roles, slogan, and ™ notice placement. No customer-facing wordmark-only or icon-only logo file is approved.

## Approved assets

| Need | Use this asset | Notes |
| --- | --- | --- |
| Primary light horizontal logo | `logo-assets/readypackets-document-stack-light.svg` | Tight horizontal full lockup |
| Primary dark horizontal logo | `logo-assets/readypackets-document-stack-dark.svg` | Tight horizontal full lockup |
| Primary light square logo | `logo-assets/readypackets-document-stack-square-light.svg` | Full square lockup for LinkedIn, social, thumbnails, and square placements |
| Primary dark square logo | `logo-assets/readypackets-document-stack-square-dark.svg` | Full square lockup for dark square placements |
| Unlimited-scale custom logo | `platform-and-print-exports/01-full-size-masters/*-vector.svg` or `*-vector.pdf` | Outlined vector source; preferred for custom resizing and print vendors |
| High-resolution raster logo | `platform-and-print-exports/01-full-size-masters/*-transparent.png` | 8,192 px horizontal or 4,096 px square transparent master |
| LinkedIn profile image | `platform-and-print-exports/02-linkedin/*-400x400.png` | Opaque square full lockup; no icon-only profile file |
| Thumbnail | `platform-and-print-exports/03-thumbnails/*-128x128.png` | Square full lockup; 256 px companion supplied |
| Website / email / print library | `platform-and-print-exports/README.md` | Full-lockup file-size map |
| Technical utility icon only | `platform-and-print-exports/04-web-email-and-app/utility-icons-only/` | Browser/OS technical exception, not a customer-facing logo |

## Placement rules

Use the horizontal full lockup in website headers, footers, portal headers, email signatures, proposals, invoices, documents, merchandise, and social covers. Use the square full lockup in LinkedIn company-profile uploads, social avatars, thumbnails, app launch surfaces, and any square brand placement.

The slogan remains centered below the company-name portion of the lockup. Preserve the supplied composition; do not pull the slogan under the symbol, move the ™ marks, detach the document stack, or substitute a compact mark in a branded logo slot.

## Light and dark rules

| Component | Light surface | Dark surface |
| --- | --- | --- |
| Background | White `#FFFFFF` | Navy `#0D1B2A` |
| Ready | Navy `#0D1B2A` | White `#FFFFFF` |
| Packets | Teal `#20A090` | Teal Light `#2EC4B6` |
| Slogan | Teal Dark `#1A7A6E` | White `#FFFFFF` |
| Divider | Gold `#C9A84C` | Gold `#C9A84C` |

Do not reverse a light logo over a dark photo, or a dark logo over a light photo. Select the matching light/dark asset and use a quiet supporting field if an image is present.

## Technical utility-icon exception

The 16/32/48 px favicon and related operating-system icon slots cannot show the company name and slogan legibly. They use the source Document-Stack mark only and are isolated under `utility-icons-only/`. They do not replace a full logo in any profile, header, document, email, marketing, social, or user-facing app surface where a full lockup fits.

## Trademark notation

The full lockups carry two ™ symbols: one after `ReadyPackets` and one after `Your Business, Professionally Packeted!`. Keep them in the supplied superscript relationship. In body copy, use **ReadyPackets™** on first prominent use in marketing and formal material, then use `ReadyPackets` consistently in subsequent references unless legal guidance requires otherwise.

The ™ notation is an unregistered trademark notice, not an assertion that registration has been granted. Follow legal counsel’s current direction before substituting ® or changing notice placement.

## Accessibility and alt text

| Context | Recommended alternative text |
| --- | --- |
| Linked primary logo | `ReadyPackets — Your Business, Professionally Packeted` |
| Decorative logo next to explicit site name | Empty `alt=""` |
| Icon-only home control | `ReadyPackets home` through visible or ARIA label |
| Social profile image | `ReadyPackets — Your Business, Professionally Packeted` |

Do not render a logo with live text as an image replacement where real, selectable page text is appropriate. In website headers, provide a descriptive link label. On marketing pages, support the visual identity with an H1 and clear semantic page content.

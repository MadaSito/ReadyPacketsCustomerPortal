# Social and Email Brand Guidance

## Social system

| Asset | Recommended use | Rule |
| --- | --- | --- |
| `platform-and-print-exports/02-linkedin/readypackets-linkedin-full-lockup-square-*-400x400.png` | LinkedIn company-profile upload | Use the light or dark **full square lockup** matching the selected surface. It includes icon, company name, divider, and slogan. |
| `templates/readypackets-social-avatar-full-lockup-square-light-1024.png` | Light social avatar master | Use for any profile surface that supports a light square full logo. |
| `templates/readypackets-social-avatar-full-lockup-square-dark-1024.png` | Dark social avatar master | Use for any profile surface that supports a dark square full logo. |
| `templates/readypackets-social-banner-light.png` | Light profile, event, campaign, or video cover | Retain protected area around the full horizontal lockup; do not crop ™ marks or slogan. |
| `templates/readypackets-social-banner-dark.png` | Dark profile, event, campaign, or video cover | Use when the platform background is dark or contrast needs a stronger treatment. |
| `templates/brand-metadata.json` | Profile descriptions and public metadata reference | Use factual descriptions; adapt length only, not meaning. |

### Social copy style

Use a direct benefit first, then a clear next action. Keep claims factual and customer-centered. Never include customer document content, order information, account information, internal workflow states, or security details in a public post.

| Post purpose | Structure | Example close |
| --- | --- | --- |
| Service education | Customer problem → practical insight → next step | Explore packet options. |
| Process update | What changed → who benefits → where to learn more | See what is new. |
| Trust content | Principle → how it is applied → supporting resource | Learn how the process works. |
| Campaign | Outcome → relevant offer/packet → explicit CTA | Start with a clear next step. |

## Email system

The reusable email signature is `templates/email-signature.html`. It uses a local CID image reference and neutral HTML for common email-client compatibility. Attach `platform-and-print-exports/04-web-email-and-app/email-signature/readypackets-full-lockup-horizontal-light-300x90.png` as the CID asset named `readypackets-full-lockup-horizontal-light-300x90.png`; do not remote-host a tracking image or logo solely to build the signature.

Replace `{{name}}`, `{{title}}`, and `{{email}}` before use. Preserve the company legal name and address unless the email system’s approved legal footer supplies them elsewhere.

### Email writing rules

- Lead with the reason for the message in the subject line and first sentence.
- Name the action, deadline, and required material plainly.
- Use branded headings sparingly; the content should remain accessible and usable when images are blocked.
- Link to a named destination such as `Review your order` rather than `Click here`.
- Do not place credentials, full order details, private documents, or authentication codes in email copy.
- Use the supplied horizontal **full lockup** for transactional, campaign, and welcome email signatures. Do not substitute a wordmark-only logo.

## Required accessibility checks

Before publishing a campaign or signature, confirm the following:

1. Logo alternative text explains the brand when the logo conveys content.
2. Text remains understandable if images are blocked.
3. Body copy, CTA labels, and link states meet contrast requirements.
4. The message does not rely on color, icons, or a hero image alone to convey next steps.
5. Mobile email line lengths and touch targets remain usable at 320 px width.

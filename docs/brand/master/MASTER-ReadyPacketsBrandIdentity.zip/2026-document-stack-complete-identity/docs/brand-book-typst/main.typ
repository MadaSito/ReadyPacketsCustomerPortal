// ReadyPackets Document-Stack Brand Book — version 2026.10.15.2
#import "report-theme.typ": report-theme

#let navy = rgb("#0D1B2A")
#let teal = rgb("#20A090")
#let teal-dark = rgb("#1A7A6E")
#let teal-light = rgb("#2EC4B6")
#let gold = rgb("#C9A84C")
#let gray = rgb("#4A5568")
#let white = rgb("#FFFFFF")

#show: report-theme.with(
  title: "ReadyPackets Brand Book",
  author: "Ready Packets Consulting LLC",
  rhythm: "report",
  running-header: true,
)
#set text(font: "Noto Sans", lang: "en")

// ---------- Cover ----------
#page(margin: (top: 2.3cm, bottom: 2.0cm, x: 2.2cm), numbering: none, header: none, fill: navy)[
  #set text(fill: white, font: "Noto Sans", lang: "en")
  #align(center)[
    #v(1.4em)
    #image("assets/logo-dark-preview.png", width: 100%)
    #v(1.7em)
    #text(size: 23pt, weight: "bold", fill: teal-light)[Document-Stack Identity System]
    #v(0.4em)
    #text(size: 12pt, fill: gold)[Complete Visual, Verbal, and Digital Brand Standards]
    #v(1.9em)
    #line(length: 62%, stroke: 0.7pt + gold)
    #v(1.4em)
    #text(size: 10pt, fill: white)[Ready Packets Consulting LLC • Version 2026.10.15.2]
  ]
]

// ---------- Contents ----------
#page(numbering: none, header: none)[
  #set text(font: "Noto Sans", lang: "en")
  #outline(title: [Contents], indent: 1.4em)
]

#counter(page).update(1)

= Brand foundation

ReadyPackets is a professional business-documentation brand built for clarity, confidence, and forward movement. The Document-Stack identity represents the work in one deliberate visual: essential information becomes organized, prepared, and ready to use.

#quote(block: true)[
  *ReadyPackets™ turns the business details that matter into professional, ready-to-use document packets.*
]

== Core identity

#table(
  columns: (1.2fr, 2fr, 2.8fr),
  inset: 7pt,
  stroke: 0.35pt + luma(185),
  fill: (x, y) => if y == 0 { luma(242) } else { none },
  table.header([*Element*], [*Approved expression*], [*Primary use*]),
  [Company name], [ReadyPackets™], [Customer-facing identity and wordmark],
  [Legal entity], [Ready Packets Consulting LLC], [Contracts, invoices, legal notices, and copyright],
  [Slogan], [Your Business, Professionally Packeted!™], [Campaigns, cover pages, full lockups, and welcome materials],
  [Short positioning], [Professional business documentation, prepared for action.], [Profiles, metadata, and compact intros],
)

== Brand pillars

#grid(
  columns: (1fr, 1fr),
  gutter: 10pt,
  [*Professionalism*\ Every touchpoint reflects expertise, clarity, and polish.],
  [*Reliability*\ Clients understand what happens next and can trust the process.],
  [*Clarity*\ Complex business needs are translated into understandable, actionable documents.],
  [*Momentum*\ The work moves businesses forward with confidence.],
)

= Logo system

== Primary light and dark lockups

#grid(
  columns: (1fr, 1fr),
  gutter: 12pt,
  figure(image("assets/logo-light-preview.png", width: 100%), caption: [Light-surface primary lockup]),
  figure(image("assets/logo-dark-preview.png", width: 100%), caption: [Dark-surface primary lockup]),
)

Every customer-facing logo uses the same complete identity: the layered Document-Stack symbol, the *ReadyPackets™* name, a Gold separator, and the smaller *Your Business, Professionally Packeted!™* supporting line. The horizontal and square lockups preserve these same components; only the composition changes to fit the placement without excess whitespace.

== Logo anatomy

#table(
  columns: (1.35fr, 3.65fr),
  inset: 7pt,
  stroke: 0.35pt + luma(185),
  [*Layered documents*], [Three staggered forms represent established information, organization, and forward-ready delivery.],
  [*Open channels*], [The internal negative space signals clarity and the ability to move through a documented process.],
  [*Forward Teal sheet*], [The Teal leading form carries momentum and active preparation.],
  [*Two-tone name*], [Ready uses Navy or White for trust and legibility; Packets uses Teal or Teal Light for motion and differentiation.],
  [*Gold rule*], [A premium completion accent and hierarchy divider; never the sole carrier of information.],
)

== Consistent full-lockup compositions

#table(
  columns: (1.25fr, 2.2fr, 1.65fr),
  inset: 7pt,
  stroke: 0.35pt + luma(185),
  table.header([*Tier*], [*Use*], [*Minimum digital width*]),
  [Horizontal full lockup], [Headers, email, sales, proposals, covers, print, banners], [300 px],
  [Square full lockup], [LinkedIn, social profile, thumbnail, app launch, square placement], [128 px],
  [Technical utility mark], [Forced browser/OS icon slots only], [16 px],
)

= Color and typography

== Color roles

#table(
  columns: (1.2fr, 1.25fr, 2.5fr, 1.3fr),
  inset: 6pt,
  stroke: 0.35pt + luma(185),
  table.header([*Token*], [*Hex*], [*Role*], [*Contrast note*]),
  [Navy], [\#0D1B2A], [Primary text, dark foundation, document depth], [17.39:1 on White],
  [Teal], [\#20A090], [Forward document and light-mode Packets], [Use with labels where required],
  [Teal Dark], [\#1A7A6E], [Light-mode slogan and accessible accent text], [5.18:1 on White],
  [Teal Light], [\#2EC4B6], [Dark-mode Packets and interaction accent], [8.02:1 on Navy],
  [Gold], [\#C9A84C], [Divider and quality accent], [2.29:1 on White—decorative only],
  [Gray Dark], [\#4A5568], [Light-surface supporting text], [7.53:1 on White],
  [White], [\#FFFFFF], [Dark-mode primary text and open space], [17.39:1 on Navy],
)

== Typography

The product and marketing system uses self-hosted *Inter* for headings, interface, and body copy. The supplied logo SVGs contain outlined Inter glyphs and must not be retyped or rebuilt manually. Use a system sans-serif fallback only when local Inter cannot be bundled.

#table(
  columns: (1.3fr, 1.1fr, 3.85fr),
  inset: 7pt,
  stroke: 0.35pt + luma(185),
  [*Brand wordmark*], [Inter 700 outlines], [Use the supplied SVG/PNG only.],
  [*Display and H1*], [Inter 600–700], [Direct, brief, purposeful; 32–64 px by context.],
  [*Body and UI*], [Inter 400–500], [16–18 px preferred, 1.5–1.7 line height.],
  [*Labels/captions*], [Inter 500–600], [14 px minimum with adequate contrast.],
)

= Voice and messaging

== Voice principles

ReadyPackets writes with calm expertise. Lead with the customer outcome, use plain English, explain requirements, and state the next step. The tone is confident without pressure and precise without unnecessary jargon.

#table(
  columns: (1.2fr, 2.3fr, 2.75fr),
  inset: 7pt,
  stroke: 0.35pt + luma(185),
  table.header([*Principle*], [*Use language that is*], [*Avoid*]),
  [Clear], [Specific, scannable, action-oriented], [Vague claims, unexplained terminology],
  [Professional], [Accurate, respectful, accountable], [Hype, pressure, casual over-familiarity],
  [Useful], [Focused on the next customer action], [Feature lists without a customer outcome],
  [Private], [Careful with customer information], [Public sharing of document, order, or security details],
)

== Approved messaging

*Positioning statement*\ ReadyPackets helps businesses organize the information that matters into professional, ready-to-use document packets.

*Customer promise*\ Your business deserves documentation that is clear, organized, and prepared for the next step.

*Homepage headline*\ *Business documentation, prepared to move forward.*

*Suggested calls to action*\ Explore packet options · Start your packet · Review your order · Learn how the process works

= Digital application

== Product and website behavior

The public marketing site and authenticated portal use the horizontal full lockup in standard headers. Square full lockups serve LinkedIn, thumbnails, social profiles, and app-launch surfaces. The compact mark is reserved for forced browser/OS technical icon slots where name and slogan cannot remain legible.

#table(
  columns: (1.4fr, 2.3fr, 2.4fr),
  inset: 7pt,
  stroke: 0.35pt + luma(185),
  table.header([*Surface*], [*Use*], [*Required safeguard*]),
  [Public site], [Discoverable, accessible public content], [Pair visual brand with semantic headings, metadata, canonical URLs, sitemap, and visible supporting text.],
  [Customer portal], [Authenticated task completion], [Use local auth/MFA, trusted sessions, role/object authorization, and noindex protected content.],
  [Mobile/PWA], [Square full lockup for launch; utility mark for forced OS icon slots], [Respect user theme, font scaling, touch targets, and icon safe zones.],
  [Email/PDF], [Horizontal full lockup], [Remain understandable when images are blocked; do not send sensitive records in open content.],
)

== Self-hosted token example

```css
:root {
  --rp-color-navy: #0D1B2A;
  --rp-color-teal-dark: #1A7A6E;
  --rp-color-gold: #C9A84C;
  --rp-font-sans: "Inter", system-ui, sans-serif;
}
```

== Correct asset selection

```tsx
const logo = darkMode
  ? "/brand/readypackets-document-stack-dark.svg"
  : "/brand/readypackets-document-stack-light.svg";
```

= Applications and governance

== Icon, social, and email system

#grid(
  columns: (1fr, 1.8fr),
  gutter: 14pt,
  figure(image("assets/logo-square-light-preview.png", width: 72%), caption: [Square full lockup for LinkedIn, social, thumbnails, and app-launch surfaces]),
  [Use the supplied square full lockup for LinkedIn company profiles, social avatars, thumbnails, and app-launch surfaces. Use the supplied horizontal full lockup in email, document, and header placements. Technical browser and operating-system icons are the only compact-mark exception because complete text cannot remain legible at favicon dimensions. Use the self-contained email signature template with a local CID logo attachment rather than a remote tracking image.],
)

== Trademark and approval rules

The ™ mark after ReadyPackets and after the official slogan represents a trademark claim. It is not a claim that a registration has issued. Use the supplied lockups rather than repositioning the marks. Obtain qualified legal guidance before converting ™ to ®, filing an application, or making statements about trademark registration or legal protection.

== Brand protection checklist

- Use light assets on light surfaces and dark assets on Navy/dark surfaces.
- Do not stretch, mirror, rotate, crop, add gradients, or redraw the mark.
- Do not convert the directional, layered symbol into radial, four-arm, cross-like, or pinwheel geometry.
- Keep Gold decorative unless large display text is independently contrast-validated.
- Use semantic labels, visible focus, sufficient contrast, and responsive asset tiers.
- Serve brand assets and fonts from ReadyPackets-controlled infrastructure only.
- Retain a versioned change record, asset hashes, approval decision, and rollback path.

= Activation checklist

Before a live rollout, obtain brand-owner approval, confirm trademark-use guidance, update every customer-facing surface in a versioned release, validate light/dark and compact behavior on real devices, check email/PDF/browser rendering, and keep the previous brand set in a historical archive until the rollback window closes.

For source asset maps, detailed usage rules, voice copy, rollout guidance, and implementation tokens, see the companion Markdown files in this package.

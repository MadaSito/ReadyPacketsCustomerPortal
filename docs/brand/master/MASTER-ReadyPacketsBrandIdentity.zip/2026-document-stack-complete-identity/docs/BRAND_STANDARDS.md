# ReadyPackets Brand Standards

**Version:** 2026.10.15.2
**Identity system:** Document-Stack Consistent Full-Lockup System
**Applies to:** Website, portal, mobile apps, sales proposals, forms, invoice/document templates, email, social, and partner materials

## 1. The brand idea

ReadyPackets helps organizations turn business information into prepared, professional deliverables. The identity expresses that promise through three layered document forms moving forward together: information becomes **organized, reliable, and ready**.

> **ReadyPackets™ turns the business details that matter into professional, ready-to-use document packets.**

The symbol is directional rather than ornamental. It is a simple visual shorthand for business documents in progress—never a generic checkmark, cloud, shield, radial mark, or abstract four-part figure.

## 2. Core identity

| Element | Approved form | Use |
| --- | --- | --- |
| Company name | **ReadyPackets™** | Primary customer-facing name and logo lockup |
| Legal entity | Ready Packets Consulting LLC | Contracts, invoices, legal notices, copyright, and formal business records |
| Primary slogan | **Your Business, Professionally Packeted!™** | Included in every customer-facing full lockup |
| Short positioning line | Professional business documentation, prepared for action. | Metadata, short intros, and support copy |
| Primary symbol | Layered Document-Stack | Part of every full logo; utility-only icon at technical browser/OS sizes |

The ™ symbol indicates a trademark claim; it is not a statement that a registration has issued. Use the mark in accordance with counsel-approved trademark and marketing policy.

## 3. Symbol meaning and construction

| Component | Meaning | Protection rule |
| --- | --- | --- |
| Rear Navy document | Established information and business foundation | Do not recolor or detach from the stack |
| Middle Navy Raised document | Review, organization, and process | Preserve the staggered layered silhouette |
| Teal forward document | Momentum and prepared action | Keep Teal as the forward-facing element |
| Open internal channels | Clarity and access to organized information | Preserve the open white/light or Navy/dark negative-space channels |
| Full lockup | A direct path from documents to a usable business identity | Use only supplied horizontal or square full compositions |

The mark must remain asymmetrical, directional, and non-rotational. Do not convert it into a four-arm pattern, pinwheel, cross-like arrangement, repeated radial geometry, or any shape that could create an unintended cultural, religious, political, or offensive association.

## 4. Logo hierarchy

| Approved composition | Customer-facing use | Required contents |
| --- | --- | --- |
| Horizontal full lockup | Headers, email, documents, print, proposals, banners, merchandise, social covers | Symbol, company ™, Gold divider, slogan ™ |
| Square full lockup | LinkedIn, social avatars, thumbnails, app launch surfaces, square placements | Symbol, company ™, Gold divider, slogan ™ |
| Technical utility mark | Browser favicon, OS tray, maskable/app icon safe zones only | Symbol only because text cannot be legible at the allocated technical size |

The technical utility mark is not a customer-facing logo choice. Use a full lockup wherever a user can reasonably see brand text.

## 5. Surface system

| Surface | Primary asset | Background |
| --- | --- | --- |
| Light horizontal | `readypackets-document-stack-light.svg` | White or very light neutral |
| Dark horizontal | `readypackets-document-stack-dark.svg` | Navy or equally dark, quiet surface |
| Light square | `readypackets-document-stack-square-light.svg` | White or very light neutral |
| Dark square | `readypackets-document-stack-square-dark.svg` | Navy or equally dark, quiet surface |
| Browser/PWA technical icon | `utility-icons-only/readypackets-utility-*` | Matching technical platform surface |

## 6. Clear space and minimum scale

Use the Gold-rule stroke height as the minimum clear-space unit, denoted **X**. Maintain at least **4X** clear space on every side of a full lockup. Do not manually crop transparent production canvases.

| Asset | Minimum digital size | Minimum print width |
| --- | ---: | ---: |
| Horizontal full lockup | 300 px wide | 42 mm |
| Square full lockup | 128 px square | 32 mm square |
| Technical utility mark | 16 px square | Not for print |

If a platform provides too little space for the full square lockup, use its profile description field with `ReadyPackets — Your Business, Professionally Packeted` and use the separated technical utility mark only when the platform forces an icon slot.

## 7. Do and do not

### Do

- Use supplied SVG files first; use transparent PNG only where SVG cannot be used.
- Use light-mode assets on light surfaces and dark-mode assets on dark surfaces.
- Maintain both ™ notices and the Gold divider in every customer-facing logo.
- Let the Navy, Teal, and Gold hierarchy carry the identity consistently.
- Use a quiet background and enough surrounding whitespace.

### Do not

- Stretch, skew, rotate, mirror, crop, trace loosely, add bevels, outline, or add unapproved shadows.
- Recolor the mark with gradients, neon, purple, or unrelated brand colors.
- Make Gold the sole color of small body text on White.
- Replace the stacked-document mark with generic folders, checkmarks, arrows, shields, or stock document icons.
- Remove the slogan, its ™, or the company ™ from a customer-facing logo file.
- Place the logo on visually busy imagery without a brand-approved supporting surface.

## 8. Brand governance

The brand owner controls master logo files, tokens, copy standards, approvals, and rollout sequencing. Do not edit exported PNGs. Amend source geometry or typography only through the self-hosted generator, regenerate the entire asset family, validate horizontal/square/light/dark variations, update checksums, document the change, and issue a versioned release.

# Brand Rollout Plan

## Purpose

Adopt the Document-Stack **consistent full-lockup** identity without breaking navigation, accessibility, public discovery, portal trust boundaries, or customer recognition. This package is versioned as a candidate; activate it through one approved release rather than piecemeal image swaps.

## Approval gates

| Gate | Owner | Exit evidence |
| --- | --- | --- |
| Brand approval | Business owner | Selected light/dark horizontal and square full lockups approved in writing |
| Trademark-use review | Qualified legal counsel | Direction on ™ placement, appropriate notice, search/filing decisions, and any restricted classes/uses |
| Accessibility review | Product/design owner | Light/dark rendering, text contrast, focus visibility, zoom, and screen-reader labels pass review |
| Technical review | Engineering/operations | Same-origin assets, responsive behavior, CSP, build, test, and security validation pass |
| Launch approval | Business owner + operations | Rollback plan, cache strategy, and complete surface inventory confirmed |

## Implementation sequence

1. **Freeze the asset version.** Use this package’s reviewed SVG/PNG/ICO sources and verify `SHA256SUMS` before copying assets.
2. **Update the brand source of truth.** Update `shared/brand.ts` and documented `BRAND_ASSETS` paths in the same pull request as static files.
3. **Install horizontal full lockups.** Add matching light/dark horizontal SVG/PNG assets for website headers, portal headers, footer, email, PDFs, and document headings.
4. **Install square full lockups.** Use matching light/dark 400 px full square assets for LinkedIn and the profile-size assets for social/app launch placements.
5. **Install technical utility icons.** Update favicon, `site.webmanifest`, browser metadata, Apple touch icon, Android/PWA icons, and native app catalogs only from the labeled `utility-icons-only/` assets where platform dimensions force an icon-only presentation.
6. **Install communication assets.** Update proposal cover, invoice masthead, email signature, social profile, social banner, support macros, and public metadata in a scheduled communications window.
7. **Validate after deploy.** Confirm browser, mobile, high-DPI, print/PDF, light/dark, private browsing, keyboard, screen-reader, and zoom behavior. Run the existing type, unit, build, and security checks.
8. **Monitor and rollback if needed.** Monitor front-end errors, customer feedback, broken asset paths, cache behavior, and email rendering. Roll back to the last approved asset set if a critical defect affects discoverability, accessibility, or customer workflows.

## Surface inventory

| Surface | Required logo composition | Required validation |
| --- | --- | --- |
| Public marketing header/footer | Horizontal full lockup | Responsive size; accessible home link; no layout shift; slogan remains intact |
| Marketing hero and proposal covers | Horizontal full lockup | Slogan legible; adequate quiet space |
| Portal header | Horizontal full lockup | Theme match; keyboard label; no component omitted |
| Admin and security center | Horizontal full lockup | No function conveyed only by color or logo |
| Browser/PWA/native technical slots | Utility icon only where platform constrains size | Maskable safe zone, 16 px favicon fallback, platform icon checks |
| Email | Horizontal full lockup | Client compatibility, alt text, no remote asset dependency |
| Social profile/banner | Square full lockup / horizontal full lockup | Crop-safe square profile and cover review |
| PDF/documents | Horizontal full lockup | Vector quality, print legibility, legal name where required |

## Rollback and retention

Keep the prior brand assets in a versioned historical archive but remove them from live public paths after the rollout is confirmed. Do not delete the prior system until the new release is validated in production and the rollback window closes. Record the change date, package version, approving owner, deployed asset hashes, affected surfaces, validation result, and rollback decision in the application audit/change log.

# Complete Brand Identity Asset Manifest

**Package:** ReadyPackets Complete Brand Identity — Document-Stack Consistent Full-Lockup System
**Version:** 2026.10.15.2
**Inventory scope:** Totals and the complete file list exclude this catalog and `SHA256SUMS`; the full package includes 180 files.

## Consistency policy

Every customer-facing logo file contains the Document-Stack symbol, ReadyPackets™ name, Gold divider, and Your Business, Professionally Packeted!™ slogan. Horizontal and square lockups use identical components. The compact mark appears only in separately labeled `utility-icons-only/` technical files for browser/OS dimensions that cannot legibly display the full identity.

## Inventory summary

| Area | Files | Primary contents |
| --- | ---: | --- |
| `logo-assets/` | 8 | Tight horizontal and square light/dark full lockups |
| `icons/` | 38 | Technical utility marks, PWA/native/browser icon family, favicon |
| `platform-and-print-exports/` | 92 | Full-size, LinkedIn, thumbnail, digital, social, print, utility, and font delivery files |
| `previews/` | 4 | Approved horizontal/square light/dark review presentations |
| `docs/` | 20 | Brand Book PDF, full-lockup standards, rollout, tokens, and sources |
| `source/` | 5 | Reproducible master/export generators and full-lockup validator |
| `templates/` | 10 | Full-lockup email, social/avatar/banner, and public metadata templates |
| **Total** | **178** | Versioned complete identity materials |

## Platform and print library

| Delivery subfolder | Files | Purpose |
| --- | ---: | --- |
| `01-full-size-masters/` | 12 | Horizontal/square SVG/PDF masters and high-resolution transparent PNGs |
| `02-linkedin/` | 4 | 400 × 400 light/dark full square lockups |
| `03-thumbnails/` | 6 | 128/256 px light/dark full square lockups |
| `04-web-email-and-app/` | 33 | Full headers/email/app-launch assets and separately labeled utility icons |
| `05-social-profiles-and-covers/` | 8 | Full square profile images and full horizontal cover assets |
| `06-print-300dpi/` | 18 | Full horizontal transparent 300-DPI business, stationery, apparel, mug, and tote files |
| `fonts/` | 10 | Inter WOFF2/TTF files and SIL Open Font License text |

## Primary production files

| Use case | Asset |
| --- | --- |
| Light horizontal logo | `logo-assets/readypackets-document-stack-light.svg` |
| Dark horizontal logo | `logo-assets/readypackets-document-stack-dark.svg` |
| Light square logo | `logo-assets/readypackets-document-stack-square-light.svg` |
| Dark square logo | `logo-assets/readypackets-document-stack-square-dark.svg` |
| LinkedIn company profile | `platform-and-print-exports/02-linkedin/*-full-lockup-square-400x400.png` |
| Browser favicon | `platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-favicon-multiresolution.ico` |
| Brand Book PDF | `docs/ReadyPackets_Document_Stack_Brand_Book_2026-10-15.pdf` |
| Font delivery | `platform-and-print-exports/fonts/` |

## Integrity

Every file below is covered by the adjacent `SHA256SUMS` release manifest, except the checksum file itself. Verify after download with `sha256sum -c SHA256SUMS` from this package directory.

## Complete file list

```text
README.md
docs/BRAND_ROLLOUT.md
docs/BRAND_STANDARDS.md
docs/COLOR_AND_TYPOGRAPHY.md
docs/DIGITAL_SYSTEM.md
docs/LOGO_USAGE.md
docs/RELEASE_NOTES.md
docs/ReadyPackets_Document_Stack_Brand_Book_2026-10-15.pdf
docs/SOCIAL_AND_EMAIL.md
docs/VOICE_AND_MESSAGING.md
docs/brand-book-typst/.typst-build-plan.json
docs/brand-book-typst/.typst-content-manifest.json
docs/brand-book-typst/.typst-document.json
docs/brand-book-typst/assets/logo-dark-preview.png
docs/brand-book-typst/assets/logo-light-preview.png
docs/brand-book-typst/assets/logo-square-dark-preview.png
docs/brand-book-typst/assets/logo-square-light-preview.png
docs/brand-book-typst/main.typ
docs/brand-book-typst/report-theme.typ
docs/tokens.css
docs/tokens.json
icons/readypackets-app-icon-1024.png
icons/readypackets-app-icon-152.png
icons/readypackets-app-icon-180.png
icons/readypackets-app-icon-192.png
icons/readypackets-app-icon-256.png
icons/readypackets-app-icon-512.png
icons/readypackets-app-icon-maskable-512.png
icons/readypackets-app-icon-maskable.svg
icons/readypackets-app-icon.svg
icons/readypackets-document-stack-mark-dark-1024.png
icons/readypackets-document-stack-mark-dark-128.png
icons/readypackets-document-stack-mark-dark-144.png
icons/readypackets-document-stack-mark-dark-152.png
icons/readypackets-document-stack-mark-dark-16.png
icons/readypackets-document-stack-mark-dark-180.png
icons/readypackets-document-stack-mark-dark-256.png
icons/readypackets-document-stack-mark-dark-32.png
icons/readypackets-document-stack-mark-dark-48.png
icons/readypackets-document-stack-mark-dark-512.png
icons/readypackets-document-stack-mark-dark-64.png
icons/readypackets-document-stack-mark-dark-72.png
icons/readypackets-document-stack-mark-dark-96.png
icons/readypackets-document-stack-mark-dark.svg
icons/readypackets-document-stack-mark-light-1024.png
icons/readypackets-document-stack-mark-light-128.png
icons/readypackets-document-stack-mark-light-144.png
icons/readypackets-document-stack-mark-light-152.png
icons/readypackets-document-stack-mark-light-16.png
icons/readypackets-document-stack-mark-light-180.png
icons/readypackets-document-stack-mark-light-256.png
icons/readypackets-document-stack-mark-light-32.png
icons/readypackets-document-stack-mark-light-48.png
icons/readypackets-document-stack-mark-light-512.png
icons/readypackets-document-stack-mark-light-64.png
icons/readypackets-document-stack-mark-light-72.png
icons/readypackets-document-stack-mark-light-96.png
icons/readypackets-document-stack-mark-light.svg
icons/readypackets-favicon.ico
logo-assets/readypackets-document-stack-dark-transparent.png
logo-assets/readypackets-document-stack-dark.svg
logo-assets/readypackets-document-stack-light-transparent.png
logo-assets/readypackets-document-stack-light.svg
logo-assets/readypackets-document-stack-square-dark-transparent.png
logo-assets/readypackets-document-stack-square-dark.svg
logo-assets/readypackets-document-stack-square-light-transparent.png
logo-assets/readypackets-document-stack-square-light.svg
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-horizontal-dark-8192w-transparent.png
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-horizontal-dark-vector.pdf
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-horizontal-dark-vector.svg
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-horizontal-light-8192w-transparent.png
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-horizontal-light-vector.pdf
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-horizontal-light-vector.svg
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-square-dark-4096x4096-transparent.png
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-square-dark-vector.pdf
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-square-dark-vector.svg
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-square-light-4096x4096-transparent.png
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-square-light-vector.pdf
platform-and-print-exports/01-full-size-masters/readypackets-full-lockup-square-light-vector.svg
platform-and-print-exports/02-linkedin/readypackets-linkedin-full-lockup-square-dark-400x400.png
platform-and-print-exports/02-linkedin/readypackets-linkedin-full-lockup-square-dark-400x400.svg
platform-and-print-exports/02-linkedin/readypackets-linkedin-full-lockup-square-light-400x400.png
platform-and-print-exports/02-linkedin/readypackets-linkedin-full-lockup-square-light-400x400.svg
platform-and-print-exports/03-thumbnails/readypackets-thumbnail-full-lockup-square-dark-128x128.png
platform-and-print-exports/03-thumbnails/readypackets-thumbnail-full-lockup-square-dark-128x128.svg
platform-and-print-exports/03-thumbnails/readypackets-thumbnail-full-lockup-square-dark-256x256.png
platform-and-print-exports/03-thumbnails/readypackets-thumbnail-full-lockup-square-light-128x128.png
platform-and-print-exports/03-thumbnails/readypackets-thumbnail-full-lockup-square-light-128x128.svg
platform-and-print-exports/03-thumbnails/readypackets-thumbnail-full-lockup-square-light-256x256.png
platform-and-print-exports/04-web-email-and-app/email-signature/readypackets-full-lockup-horizontal-dark-300x90.png
platform-and-print-exports/04-web-email-and-app/email-signature/readypackets-full-lockup-horizontal-light-300x90.png
platform-and-print-exports/04-web-email-and-app/full-square-app-and-launch/readypackets-full-lockup-square-dark-152x152.png
platform-and-print-exports/04-web-email-and-app/full-square-app-and-launch/readypackets-full-lockup-square-dark-180x180.png
platform-and-print-exports/04-web-email-and-app/full-square-app-and-launch/readypackets-full-lockup-square-dark-192x192.png
platform-and-print-exports/04-web-email-and-app/full-square-app-and-launch/readypackets-full-lockup-square-dark-512x512.png
platform-and-print-exports/04-web-email-and-app/full-square-app-and-launch/readypackets-full-lockup-square-light-152x152.png
platform-and-print-exports/04-web-email-and-app/full-square-app-and-launch/readypackets-full-lockup-square-light-180x180.png
platform-and-print-exports/04-web-email-and-app/full-square-app-and-launch/readypackets-full-lockup-square-light-192x192.png
platform-and-print-exports/04-web-email-and-app/full-square-app-and-launch/readypackets-full-lockup-square-light-512x512.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-app-icon-maskable-512x512.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-app-icon-maskable-vector.svg
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-app-icon-navy-152x152.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-app-icon-navy-180x180.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-app-icon-navy-192x192.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-app-icon-navy-512x512.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-favicon-multiresolution.ico
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-mark-dark-16x16.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-mark-dark-192x192.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-mark-dark-32x32.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-mark-dark-48x48.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-mark-dark-512x512.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-mark-light-16x16.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-mark-light-192x192.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-mark-light-32x32.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-mark-light-48x48.png
platform-and-print-exports/04-web-email-and-app/utility-icons-only/readypackets-utility-mark-light-512x512.png
platform-and-print-exports/04-web-email-and-app/website-header/readypackets-full-lockup-horizontal-dark-300x90.png
platform-and-print-exports/04-web-email-and-app/website-header/readypackets-full-lockup-horizontal-dark-500x150.png
platform-and-print-exports/04-web-email-and-app/website-header/readypackets-full-lockup-horizontal-light-300x90.png
platform-and-print-exports/04-web-email-and-app/website-header/readypackets-full-lockup-horizontal-light-500x150.png
platform-and-print-exports/04-web-email-and-app/website-hero/readypackets-full-lockup-horizontal-dark-500x138.png
platform-and-print-exports/04-web-email-and-app/website-hero/readypackets-full-lockup-horizontal-light-500x138.png
platform-and-print-exports/05-social-profiles-and-covers/cover-images/readypackets-full-lockup-horizontal-dark-820x312.png
platform-and-print-exports/05-social-profiles-and-covers/cover-images/readypackets-full-lockup-horizontal-dark-820x312.svg
platform-and-print-exports/05-social-profiles-and-covers/cover-images/readypackets-full-lockup-horizontal-light-820x312.png
platform-and-print-exports/05-social-profiles-and-covers/cover-images/readypackets-full-lockup-horizontal-light-820x312.svg
platform-and-print-exports/05-social-profiles-and-covers/profile-images/readypackets-full-lockup-square-dark-180x180.png
platform-and-print-exports/05-social-profiles-and-covers/profile-images/readypackets-full-lockup-square-dark-800x800.png
platform-and-print-exports/05-social-profiles-and-covers/profile-images/readypackets-full-lockup-square-light-180x180.png
platform-and-print-exports/05-social-profiles-and-covers/profile-images/readypackets-full-lockup-square-light-800x800.png
platform-and-print-exports/06-print-300dpi/business-cards/readypackets-full-lockup-horizontal-dark-450x193-300dpi.png
platform-and-print-exports/06-print-300dpi/business-cards/readypackets-full-lockup-horizontal-light-450x193-300dpi.png
platform-and-print-exports/06-print-300dpi/hats/readypackets-hat-full-lockup-horizontal-dark-1050x290-300dpi.png
platform-and-print-exports/06-print-300dpi/hats/readypackets-hat-full-lockup-horizontal-light-1050x290-300dpi.png
platform-and-print-exports/06-print-300dpi/letterhead-and-invoices/readypackets-full-lockup-horizontal-dark-600x180-300dpi.png
platform-and-print-exports/06-print-300dpi/letterhead-and-invoices/readypackets-full-lockup-horizontal-light-600x180-300dpi.png
platform-and-print-exports/06-print-300dpi/mugs/readypackets-mug-full-lockup-horizontal-dark-2250x622-300dpi.png
platform-and-print-exports/06-print-300dpi/mugs/readypackets-mug-full-lockup-horizontal-light-2250x622-300dpi.png
platform-and-print-exports/06-print-300dpi/tote-bags/readypackets-tote-full-lockup-horizontal-dark-4200x4800-300dpi.png
platform-and-print-exports/06-print-300dpi/tote-bags/readypackets-tote-full-lockup-horizontal-dark-4200x4800-300dpi.svg
platform-and-print-exports/06-print-300dpi/tote-bags/readypackets-tote-full-lockup-horizontal-light-4200x4800-300dpi.png
platform-and-print-exports/06-print-300dpi/tote-bags/readypackets-tote-full-lockup-horizontal-light-4200x4800-300dpi.svg
platform-and-print-exports/06-print-300dpi/tshirts/readypackets-tshirt-large-full-lockup-horizontal-dark-4200x4500-300dpi.png
platform-and-print-exports/06-print-300dpi/tshirts/readypackets-tshirt-large-full-lockup-horizontal-dark-4200x4500-300dpi.svg
platform-and-print-exports/06-print-300dpi/tshirts/readypackets-tshirt-large-full-lockup-horizontal-light-4200x4500-300dpi.png
platform-and-print-exports/06-print-300dpi/tshirts/readypackets-tshirt-large-full-lockup-horizontal-light-4200x4500-300dpi.svg
platform-and-print-exports/06-print-300dpi/tshirts/readypackets-tshirt-pocket-full-lockup-horizontal-dark-1313x363-300dpi.png
platform-and-print-exports/06-print-300dpi/tshirts/readypackets-tshirt-pocket-full-lockup-horizontal-light-1313x363-300dpi.png
platform-and-print-exports/README.md
platform-and-print-exports/fonts/OFL.txt
platform-and-print-exports/fonts/README.md
platform-and-print-exports/fonts/desktop-ttf/Inter-Bold.ttf
platform-and-print-exports/fonts/desktop-ttf/Inter-Medium.ttf
platform-and-print-exports/fonts/desktop-ttf/Inter-Regular.ttf
platform-and-print-exports/fonts/desktop-ttf/Inter-SemiBold.ttf
platform-and-print-exports/fonts/webfonts-woff2/inter-400.woff2
platform-and-print-exports/fonts/webfonts-woff2/inter-500.woff2
platform-and-print-exports/fonts/webfonts-woff2/inter-600.woff2
platform-and-print-exports/fonts/webfonts-woff2/inter-700.woff2
previews/readypackets-document-stack-dark-preview.png
previews/readypackets-document-stack-light-preview.png
previews/readypackets-document-stack-square-dark-preview.png
previews/readypackets-document-stack-square-light-preview.png
source/PLATFORM_EXPORT_SOURCES.md
source/SOURCE_NOTES.md
source/build_document_stack_brand_assets.py
source/build_platform_and_print_exports.py
source/validate_complete_brand_package.py
templates/brand-metadata.json
templates/email-signature.html
templates/readypackets-social-avatar-full-lockup-square-dark-1024.png
templates/readypackets-social-avatar-full-lockup-square-dark.svg
templates/readypackets-social-avatar-full-lockup-square-light-1024.png
templates/readypackets-social-avatar-full-lockup-square-light.svg
templates/readypackets-social-banner-dark.png
templates/readypackets-social-banner-dark.svg
templates/readypackets-social-banner-light.png
templates/readypackets-social-banner-light.svg
```

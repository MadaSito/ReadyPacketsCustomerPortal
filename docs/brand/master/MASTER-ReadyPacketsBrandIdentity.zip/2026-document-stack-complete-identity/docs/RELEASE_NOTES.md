# Release Notes — Complete Document-Stack Brand Identity

**Release:** 2026.10.15.2
**Date:** October 15, 2026
**Status:** Production candidate; live activation pending brand-owner approval and trademark-use review

## 2026.10.15.2 — Consistent full-lockup correction

This release replaces the earlier mixed logo tier delivery with a consistent customer-facing full-lockup system. The user reported that LinkedIn contained too much whitespace and displayed only the icon, while website and email files omitted the slogan. The correction rebuilds the master package so every branded logo file carries the layered document icon, `ReadyPackets™`, Gold divider, and `Your Business, Professionally Packeted!™`.

The refreshed package supplies two tightly framed compositions using the same components: a horizontal full lockup for wide placements and a square full lockup for LinkedIn, thumbnails, profiles, and square placements. LinkedIn now uses an opaque, tightly framed 400 × 400 square full-lockup asset rather than an icon-only mark. The only compact marks that remain are explicitly labeled technical utility icons for browser/OS slots where text cannot be rendered legibly, including 16/32/48 px favicon contexts.

## Included

- Light/dark horizontal and square primary full lockups with company and slogan ™ notices.
- Horizontal and square SVG/PDF vector masters plus 8,192 px horizontal and 4,096 px square transparent PNG masters.
- Light/dark 400 × 400 LinkedIn full-lockup profile images and SVGs.
- Light/dark 128/256 px thumbnail full-lockup files.
- Full-lockup website header, email, hero, social profile, social cover, print, and app-launch assets.
- Clearly separated technical utility icon family and multi-resolution favicon.
- A revised Brand Book PDF, brand standards, digital system, social/email guidance, rollout plan, tokens, source generator, validation script, asset manifest, and SHA-256 integrity manifest.
- Self-hosted Inter WOFF2/TTF fonts with SIL Open Font License text.

## Key design decisions

- The directional, asymmetric layered-document symbol replaces any geometry that could resemble a radial, four-arm, cross-like, or offensive motif.
- Every branded logo preserves the same visual components and trademark notices; only wide versus square composition changes to preserve readability and avoid excess whitespace.
- Light mode uses Navy + Teal + Deep Teal + Gold on White; dark mode uses White + Teal Light + Gold on Navy.
- SVG lettering uses local Inter glyph outlines; no runtime CDN, remote font, Manus resource, or external design-tool dependency is introduced.

## Activation boundary

This release adds a **brand package only**. It does not replace live static assets, favicons, browser metadata, PWA manifests, mobile catalogs, component code, public copy, or `shared/brand.ts`. Follow `BRAND_ROLLOUT.md` for an approved, reversible implementation release.

## Verification

- All SVGs parse as XML and contain titles/descriptions with no live `<text>` elements.
- Full lockups include separate outlined ™ glyphs for company and slogan notice placement.
- LinkedIn/profile/thumbnail files are verified to contain full square lockups rather than the legacy compact mark.
- Transparent assets retain alpha; opaque profile/social assets use expected canvas dimensions; print PNGs retain 300-DPI metadata.
- The revised Brand Book PDF compiles with strict Typst validation and passes publication-profile verification.
- The release-level `SHA256SUMS` file validates the packaged materials.

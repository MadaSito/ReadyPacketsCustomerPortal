# Color and Typography System

## Color palette

| Token | Hex | Purpose | Light contrast note |
| --- | --- | --- | --- |
| Navy | `#0D1B2A` | Trust, primary name, dark foundations, primary text | 17.39:1 on White |
| Navy Raised | `#12263A` | Layered document depth, deep surfaces | 15.62:1 on White |
| Teal | `#20A090` | Forward document, active interface accents, `Packets` on light | Decorative on White; pair with labels/text where required |
| Teal Dark | `#1A7A6E` | Light-mode slogan, links, accessible accent text | 5.18:1 on White |
| Teal Light | `#2EC4B6` | `Packets` on Navy, selected highlights | 8.02:1 on Navy |
| Gold | `#C9A84C` | Divider, completion accent, premium emphasis | 2.29:1 on White; never small text alone |
| Gold Dark | `#A98C36` | Secondary ornament on light surfaces | Decorative or large display use only |
| Gray Dark | `#4A5568` | Support copy, muted text on light surfaces | 7.53:1 on White |
| White | `#FFFFFF` | Open space, dark-mode primary text | 17.39:1 on Navy |

### Functional color rules

- Use **Navy** or **Gray Dark** for primary body text on light surfaces.
- Use **White** for primary body text on Navy surfaces.
- Use **Teal Dark** for text links or smaller color text on White; do not rely on Teal alone for body text.
- Use **Gold** as a divider, keyline, status accent, or large display accent. Never use Gold as the only way to communicate state or meaning.
- Pair color states with plain-language labels, icons with accessible names, and programmatic semantics.

## Typography

| Role | Preferred family | Weight | Guidance |
| --- | --- | --- | --- |
| Brand wordmark | Outlined local Inter in supplied SVG masters | 700 | Do not recreate manually; use supplied lockups |
| Product and marketing headings | Inter | 600–700 | Short, declarative, clear hierarchy |
| Body and UI | Inter | 400–500 | Sentence case, readable line length, 16 px minimum for body UI |
| Metadata, labels, captions | Inter | 500–600 | Use sufficient size and contrast; never reduce to decorative illegibility |
| System fallback | `system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif` | inherited | Use when Inter cannot be bundled |

The ReadyPackets product already self-hosts Inter WOFF2 assets under `client/public/fonts/`. Do not import fonts from Google Fonts or another remote provider. Logo artwork has outlined glyphs and no font runtime dependency.

## Type scale and layout

| Token | Desktop recommendation | Mobile recommendation | Use |
| --- | ---: | ---: | --- |
| Display | 48–64 px | 36–44 px | Campaign / hero headline |
| H1 | 40–48 px | 32–36 px | Page title |
| H2 | 28–32 px | 24–28 px | Major section |
| H3 | 20–24 px | 18–22 px | Component heading |
| Body | 16–18 px | 16–18 px | Default copy |
| Small label | 14 px minimum | 14 px minimum | Metadata or utility label |

Keep line-height roughly 1.2–1.3 for headings and 1.5–1.7 for body copy. Never rely on all caps for long content, and ensure responsive type honors browser zoom, Dynamic Type, and user font-scaling preferences.

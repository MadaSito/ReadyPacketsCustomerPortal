# Digital Brand System

## Experience model

ReadyPackets uses one full visual identity across the public marketing site, authenticated portal, mobile applications, email, and documents. Customer-facing surfaces use either the horizontal or square full lockup; both include the Document-Stack symbol, company name, divider, and slogan.

| Surface | Role | Recommended logo composition | Theme default |
| --- | --- | --- | --- |
| `www.readypackets.com` | Public discovery, catalog, policies, conversion | Horizontal full lockup in header, footer, and hero | Light with intentional dark campaign sections |
| `myportal.readypackets.com` | Authenticated customer/staff/admin work | Horizontal full lockup in header; square full lockup where a square identity tile is used | System-aware light/dark with accessibility-safe tokens |
| Native mobile | Authenticated companion workflows | Square full lockup for launch/marketing; technical utility mark only in forced OS icon slots | System-aware light/dark |
| Email and PDFs | Confirmation, delivery, sales, service | Horizontal full lockup | Light by default, Navy cover as appropriate |
| Social | Recognition and campaign distribution | Square full lockup for profiles; horizontal full lockup for covers | Selected platform-safe light or dark asset |

## UI principles

1. **Clarity before decoration.** Use the complete lockup as a focused identifier, not a repeated background motif.
2. **Calm precision.** Navy anchors high-trust actions and content; Teal identifies positive momentum and current focus; Gold is a finishing accent.
3. **Accessible by default.** Meet WCAG 2.2 AA text contrast, preserve visible focus, support keyboard and screen-reader flows, and respect reduced motion.
4. **Consistent full identity.** Use horizontal full lockup in wide spaces and square full lockup in square spaces. Do not substitute a wordmark-only or icon-only logo in a customer-facing placement.
5. **Self-hosted delivery.** Serve local logo, font, and UI assets from ReadyPackets-controlled infrastructure. Do not add a CDN, remote font import, Manus service, or platform-specific client dependency.

## Theme behavior

Use `prefers-color-scheme` or an explicit user-controlled theme. Persist a user-selected theme only after it is chosen; do not force dark mode or rely on color alone for success, warnings, errors, or workflow status.

| Semantic role | Light theme | Dark theme |
| --- | --- | --- |
| Canvas | White | Navy |
| Primary text | Navy | White |
| Secondary text | Gray Dark | `#CBD5E1` |
| Interactive accent | Teal Dark | Teal Light |
| Brand highlight | Teal | Teal Light |
| Divider / completion accent | Gold | Gold |
| Destructive action | Accessible semantic red with text/icon | Accessible semantic red with text/icon |

## Implementation snippets

Load local full-lockup assets using ordinary same-origin paths:

```html
<img
  src="/brand/readypackets-document-stack-light.svg"
  alt="ReadyPackets — Your Business, Professionally Packeted"
  width="500"
  height="138"
/>
```

Switch full logo asset with the selected surface rather than applying CSS filters:

```tsx
const logo = darkMode
  ? "/brand/readypackets-document-stack-dark.svg"
  : "/brand/readypackets-document-stack-light.svg";
```

Use the square full lockup for company profile surfaces:

```tsx
const profileLogo = darkMode
  ? "/brand/readypackets-document-stack-square-dark.svg"
  : "/brand/readypackets-document-stack-square-light.svg";
```

## Discoverability and accessible branding

The public marketing site should pair visual identity with discoverable semantic content: one descriptive H1 per page, concise title/description metadata, canonical URLs, `sitemap.xml`, restrictive portal/admin robots directives, structured data only for visible and supportable facts, and descriptive alt text. Avoid image-only headlines, vague navigation labels, and keyword-stuffed copy.

The protected portal, administration, file delivery, exports, and internal API routes must not be publicly indexed. Do not use social sharing or analytics snippets that disclose customer, order, document, or security information.
